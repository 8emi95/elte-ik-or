package chat.parallel;

import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

/**
 * A chatkliens főosztálya.
 */
public class ChatClient implements Runnable {

	/**
	 * Tárolja, hogy a szerverrel való kapcsolat él-e még.
	 * <p>
	 * A {@code volatile} kulcsszó itt a szálbiztonság miatt fontos.
	 * Szinkronizációt nem jelent, tehát ha többször egymás után olvassuk vagy
	 * írjuk a változót, akkor az írásai/olvasásai között fel kell tennünk, hogy
	 * más szálak tetszőelgesen módosíthatják az értékét.
	 * <p>
	 * A közös adatok elérésekor viszont egy másik fontos probléma is van
	 * párhuzamosságnál: a szálak cache-elhetik a változók értékét, és
	 * mindaddig, amíg nincsenek rákényszerítve, hogy a közös memóriából
	 * kiolvassák a valóban ott lévő értéket, mindvégig a cache-elt értéket
	 * használhatják. Amíg egy szálunk van, ez nem okoz gondot, egy szál a saját
	 * cache-elt értékeit karban tartja, de más szálak módosíthatják a
	 * memóriában lévő értéket. Ezen segít a {@code volatile}: a szálakat arra
	 * kényszeríti, hogy sose cache-eljék ennek a változónak az értékét, hanem
	 * mindig a memóriából olvassák és oda írják közvetlen.
	 * <p>
	 * <i>Megjegyzés</i>: szinkronizációkor a szálak az összes cache-elt értéket
	 * lementik/újraolvassák, tehát a {@code volatile} használatára csak
	 * olyankor van szükség, ha szinkronizálni nem akarunk.
	 */
	volatile boolean connectedToServer = false;

	private final String host;
	private final int port;

	/**
	 * Letárolja a hoszt nevét és a portszámot, hogy a {@link run} metódus
	 * kiolvashassa azokat.
	 */
	ChatClient(String host, int port) {
		this.host = host;
		this.port = port;
	}

	/**
	 * Létrehozza a kapcsolatot a szerverrel, elküldi a nevét, majd elindítja a
	 * két oldali kommunikációért felelős szálakat.
	 */
	@Override
	public void run() {
		try (Socket client = new Socket(host, port);
				PrintWriter pw = new PrintWriter(client.getOutputStream());
				Scanner sc = new Scanner(client.getInputStream())) {

			Scanner console = new Scanner(System.in);

			// Név bekérése, átküldése.
			// Kis kiegészítés a feladathoz: csak értelmes nevet engedünk.
			String answer;
			do {
				System.out.print("Name: ");
				pw.println(console.nextLine());
				pw.flush();
				answer = sc.nextLine();
			} while (!"ok".equals(answer));

			System.out.println("Connected to server.");
			
			connectedToServer = true;

			// Létrehozzuk a szálakat.
			Thread sender = new SenderThread(pw, console, this);
			Thread accept = new AcceptThread(sc, this);

			// Szálak elindítása párhuzamosan.
			sender.start();
			accept.start();

			// A 'join' metódussal bevárjuk, amíg az egyik, majd amíg a másik
			// szál le nem áll.
			sender.join();
			accept.join();

			// Ha mindkét szál végzett, kilépünk, és egyúttal le is zárunk
			// magunk után mindent a try-with-resource miatt.
		} catch (Exception e) {
			System.err.println("Error while connecting to server.");
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		new ChatClient("localhost", 12345).run();
	}

}

/**
 * Fogadja a szervertől érkező sorokat, és kiírja a képernyőre.
 */
class AcceptThread extends Thread {
	private final Scanner sc;
	private final ChatClient client;

	/**
	 * Megkapja a szervertől jött üzeneteket olvasó {@link Scanner}t és a kliens
	 * példányát.
	 */
	AcceptThread(Scanner sc, ChatClient client) {
		this.sc = sc;
		this.client = client;
	}

	@Override
	public void run() {
		while (sc.hasNextLine()) {
			System.out.println(sc.nextLine());
		}
		System.out.println("The server closed the connection.");

		// Jelzés a másik szálnak.
		client.connectedToServer = false;
	}
}

/**
 * Olvassa a standard inputot (konzolt), és továbbküldi a szervernek.
 */
class SenderThread extends Thread {

	private final PrintWriter pw;
	private final Scanner console;
	private final ChatClient client;

	/**
	 * Megkapja a szerver felé író {@link PrintWriter}t, a standard inputról
	 * olvasó {@link Scanner}t és a kliens példányát.
	 */
	SenderThread(PrintWriter pw, Scanner console, ChatClient client) {
		this.pw = pw;
		this.console = console;
		this.client = client;
	}

	@Override
	public void run() {
		try {
			while (client.connectedToServer) {
				pw.println(console.nextLine());
				pw.flush();
			}
		} catch (Exception e) {
			System.err.println("Error in sender thread.");
			e.printStackTrace();
		}
	}
}