package chat.parallel;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 * A chatszerver főosztálya. Ezúttal a klienseket fogadó szál mellett minden
 * egyes klienshez rendelni fogunk egy saját szálat.
 */
public class ChatServer implements Runnable {

	private final int port;

	/**
	 * A kliensek nevéhez a hozzájuk tartozó {@link PrintWriter}t rendelő map.
	 * Mivel ezt a változót mindkét szál használhatja, ezért szinkronizációval
	 * kell védeni.
	 */
	private Map<String, PrintWriter> clients = new HashMap<String, PrintWriter>();

	/**
	 * Letárolja a portszámot, hogy a {@link run} metódus kiolvashassa azt.
	 */
	ChatServer(int port) {
		this.port = port;
	}

	@Override
	public void run() {
		try (ServerSocket server = new ServerSocket(port)) {
			acceptClients(server);
		} catch (IOException e) {
			System.err.println("Error in server startup.");
			e.printStackTrace();
		}
	}

	/**
	 * Egy végtelen ciklusban próbálkozik kapcsolatot létesíteni új kliensekkel.
	 */
	private void acceptClients(ServerSocket server) {
		System.out.println("Server: running and waiting for clients.");
		while (true) {
			try {
				new ClientHandler(server.accept()).start();
			} catch (IOException e) {
				System.err.println("Server: error while connecting to client.");
				e.printStackTrace();
			}
		}
	}

	/*
	 * A következő metódusok synchronized kulcsszóval lettek ellátva. Ez annak a
	 * szintaktikai egyszerűsítése, mintha a metódus teljes tartalmát
	 * körbevennénk egy
	 * 
	 * synchronized (this) {
	 * 
	 * }
	 * 
	 * blokkal. Tehát ez mindig az aktuális objektumra (itt a szerver főosztály
	 * aktuális példánya) szinkronizálunk. A szerver adatait tároló mapet,
	 * valamint a klienseknek író PrintWriter példányokat csak ezekben a
	 * metódusokban fogjuk elérni, így elérve a szálbiztonságot.
	 */

	/**
	 * Ellenőrzi a nevet, és hozzáadja a kliensekhez, ha jó.
	 */
	private synchronized boolean addClient(String name, PrintWriter pw) {
		if (name.trim().equals("") || name.equals("Server") || clients.containsKey(name)) {
			return false;
		}
		// Megfelel a feltételeknek, létrehozhatjuk a klienst.

		send("Server", "'" + name + "' connected.");
		clients.put(name, pw);
		return true;
	}

	/**
	 * Töröl egy klienst.
	 */
	private synchronized void removeClient(String name) {
		clients.remove(name);
	}

	/**
	 * A küldőt kivéve mindenkinek elküldi az üzenetet.
	 */
	private synchronized void send(String name, String message) {
		String messageToSend = name + ": " + message;
		System.out.println(messageToSend);
		for (String n : clients.keySet()) {
			if (!n.equals(name)) {
				PrintWriter pw = clients.get(n);
				pw.println(messageToSend);
				pw.flush();
			}
		}
	}

	/**
	 * Osztály egy kliens kezeléséhez. Mivel belső osztály, ezért van egy
	 * implicit hivatkozása az őt tartalmazó szerverre.
	 * <p>
	 * Önálló szál!
	 */
	private class ClientHandler extends Thread {

		final Socket socket;
		final PrintWriter pw;
		final Scanner sc;
		String name;

		ClientHandler(Socket socket) throws IOException {
			this.socket = socket;
			pw = new PrintWriter(socket.getOutputStream());
			sc = new Scanner(socket.getInputStream());
		}

		@Override
		public void run() {
			try {
				boolean ready = false;
				while (!ready) {
					if (!sc.hasNextLine()) {
						// Ha a másik fél lezárta a csatornát (még mielőtt
						// bármit küldött volna).
						System.err.println("Server: initialization problem with client.");
						return;
					}
					name = sc.nextLine();
					ready = addClient(name, pw);
					pw.println(ready ? "ok" : "not ok");
					pw.flush();
				}
			} catch (Exception e) {
				// Ha a másik féllel megszakadt a kapcsolat (lezárta a csatornat
				// vagy befejeződött).
				System.err.println("Server: initialization problem with client.");
				return;
			}

			// Üzenetek fogadása és továbbküldése.
			try {
				while (true) {
					if (!sc.hasNextLine()) {
						break;
					}
					String message = sc.nextLine();
					if (message.equals("!exit")) {
						break;
					}
					send(name, message);
				}
			} finally {
				removeClient(name);
				try {
					socket.close();
					sc.close();
					pw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				send("Server", "'" + name + "' logged out.");
			}
		}

	}

	public static void main(String[] args) {
		new ChatServer(12345).run();
	}

}
