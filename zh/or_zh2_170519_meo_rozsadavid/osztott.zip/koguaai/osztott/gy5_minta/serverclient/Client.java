package serverclient;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

/**
 * Számokat küld 10-től 1-ig a szervernek, és a kapott választ megjeleníti a
 * képernyőn, majd kilép.
 */
public class Client {

	public static void main(String[] args) throws IOException {
		runClient();
	}

	public static void runClient() {
		try {
			final String hostname = "localhost";
			final int port = 12345;

			try (Socket s = new Socket(hostname, port);
					Scanner sc = new Scanner(s.getInputStream());
					PrintWriter pw = new PrintWriter(s.getOutputStream());) {

				for (int i = 10; i >= 0; --i) {
					pw.println(i);
					pw.flush();

					System.out.println(sc.nextLine());
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
