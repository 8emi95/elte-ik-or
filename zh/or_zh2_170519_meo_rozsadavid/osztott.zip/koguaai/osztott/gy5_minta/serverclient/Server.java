package serverclient;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 * Egyszerre egy klienssel létesít kapcsolatot, akitől folyamatosan egész
 * számokat fogad, és ezeket hozzáaadja egy tárolt (kezdetben 0) számhoz, az
 * eddigi összeget pedig elküldi a kliensnek. Ha a kliens 0-t küld, a szerver
 * megszakítja a kapcsolatot, és a következő kliensre vár.
 */
public class Server {

	private static int number = 0;

	public static void main(String[] args) throws IOException {
		runServer();
	}

	public static void runServer() {
		try {
			final int port = 12345;

			try (ServerSocket ss = new ServerSocket(port)) {
				while (true) {
					handleClient(ss);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void handleClient(ServerSocket ss) throws IOException {
		try (Socket s = ss.accept();
				Scanner sc = new Scanner(s.getInputStream());
				PrintWriter pw = new PrintWriter(s.getOutputStream())) {

			while (true) {
				int n = sc.nextInt();

				number += n;

				pw.println(number);
				pw.flush();

				if (n == 0) {
					break;
				}
			}

		}
	}
}
