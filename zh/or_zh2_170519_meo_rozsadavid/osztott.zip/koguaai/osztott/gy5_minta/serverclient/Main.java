package serverclient;

public class Main {

	public static void main(String[] args) {

		// Elindít egy szervert egy külön szálon.
		new Thread(new Runnable() {
			@Override
			public void run() {
				Server.runServer();
			}
		}).start();

		// Elindít 5 klienst egy-egy külön szálon.
		for (int i = 0; i < 5; ++i) {
			new Thread(new Runnable() {
				@Override
				public void run() {
					Client.runClient();
				}
			}).start();
		}
	}

}
