package threads;

/**
 * Egy burkoló osztály egy egész szám köré. Nem más gyakorlatilag, mint egy
 * mutable (módosítható) egész szám. A fontosságához lásd a DecreaseNumber
 * osztályt.
 * 
 */
public class Counter {

	public int value = 100;

}
