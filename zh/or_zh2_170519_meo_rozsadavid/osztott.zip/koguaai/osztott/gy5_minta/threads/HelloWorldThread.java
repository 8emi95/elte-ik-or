package threads;

/**
 * Egy szálosztály, melynek példányai 100-szor kiírják a képernyőre a nevüket,
 * és hogy 'Hello World!', jelezve, hogy éppen hányadik kiírásnál tartanak.
 * Annak érdekében, hogy a szálak által kiírt szöveg ne keveredhessen össze (az
 * összekeveredés jobb szemléltetése érdekében a szöveget karakterenként írjuk
 * ki), egy, a szálak számára közös objektumra szinkronizálnak. Ez az objektum
 * itt az osztályszintű lock.
 */
public class HelloWorldThread extends Thread {

	private static Object lock = new Object();
	private String name;

	public HelloWorldThread(String name) {
		this.name = name;
	}

	@Override
	public void run() {
		synchronized (lock) {
			for (int i = 0; i < 100; ++i) {
				String s = (i + 1) + ". [" + name + "]: Hello World!";
				for (char c : s.toCharArray()) {
					System.out.print(c);
				}
				System.out.println();
			}
		}

	}

}
