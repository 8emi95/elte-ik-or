package threads;

/**
 * Ennek az osztálynak a példányai egy közös (statikus) egész változót akarnak
 * 100-ról 0-ra csökkenteni, párhuzamosíthatóan. Annak érdekében, hogy a szálak
 * munkája ne keveredjen össze, ne piszkálhassanak bele egymás munkájába, ezt a
 * közösen használt számot szinkronizációval védjük. Figyelnünk kell arra, hogy
 * mindig ugyanarra az objektumra szinkronizáljunk, ezért nem jó megoldás, hogy
 * int helyett a number egy Integer lesz, és mindig erre szinkronizálunk, hiszen
 * ennek módosítjuk az értékét, a változó más-más objektumra fog mutatni, így a
 * szálak más-más objektumra szinkronizálnának. Ezért vagy egy tárolót
 * használunk, és arra szinkronizálunk (lásd Counter osztály), vagy egy külön
 * lock objektumot (lásd LOCK_ON_NUMBER), melynek a típusa nem lényeges, ezért
 * Objectnek szoktuk hagyni.
 * <p>
 * A szinkronizácói jobb szemléltetésére van beleépítve a várakozás, illetve a
 * szövegkiírás a végén.
 */
public class DecreaseNumber implements Runnable {

	// private static final Counter counter = new Counter();

	private static int number = 100;

	private static final Object LOCK_ON_NUMBER = new Object();

	@Override
	public void run() {
		while (true) {
			synchronized (LOCK_ON_NUMBER /* counter */) {
				if (/* counter.value <= 0 */ number <= 0) {
					break;
				}
				int tmp = /* counter.value */ number;
				--tmp;

				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
				}

				/* counter.value = tmp */ number = tmp;
				System.out.println(tmp);
			}

			synchronized (LOCK_ON_NUMBER) {
				for (char c : "Hello World".toCharArray()) {
					System.out.print(c);
					try {
						Thread.sleep(10);
					} catch (InterruptedException e) {
					}
				}
				System.out.println();
			}

		}
	}

}
