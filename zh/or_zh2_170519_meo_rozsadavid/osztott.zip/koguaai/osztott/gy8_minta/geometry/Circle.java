package geometry;

import java.io.Serializable;

public class Circle implements Serializable {
	/*
	 * Szerializálhatóság feltétele: megvalósítja a java.io.Serializable
	 * interfészt, és minden (nem statikus és nem transient) adattagja
	 * szerializálható.
	 */

	/*
	 * serialVersionUID: Nem feltétlenül szükséges, ha van is, egy generált
	 * véletlen szám. Akkor van szerepe, ha olyan alkalmazásban használjuk, ahol
	 * a lementés és a visszatöltés esetén megváltozhat az osztályunk (pl.
	 * archiválunk, és hónapokkal később töljük vissza). Ez a verziószám jelzi,
	 * hogy azonos változatot akarunk-e visszatölteni, ha nem, akkor hibát dob a
	 * betöltés. (Nincs jelentősége a konkrét értéknek, csak az számít, hogy
	 * betöltéskor ugyanaz-e, mint lementéskor volt.)
	 */
	private static final long serialVersionUID = 917120668560213533L;

	private Point center;
	private int r;
	/*
	 * transient: a így megjelölt adattagokat a szerializáció figyelmen kívül
	 * hagyja, nem írja ki és nem olvassa be őket (az olvasás után alapértékre
	 * inicializálódnak, objektumok esetén nullra).
	 */
	private transient Double area = null;

	public Circle(Point center, int r) {
		this.center = center;
		this.r = r;
	}

	public double getArea() {
		if (area == null) {
			area = new Double(r * r * Math.PI);
		}
		return area;
	}

	public void move(int dx, int dy) {
		center.move(dx, dy);
	}

	@Override
	public String toString() {
		return center + " r: " + r + " area: " + area;
	}

}