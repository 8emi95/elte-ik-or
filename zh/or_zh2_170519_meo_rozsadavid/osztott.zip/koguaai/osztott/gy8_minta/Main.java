import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import geometry.Circle;
import geometry.Point;

public class Main {

	public static void main(String[] args) {
		Circle c1 = new Circle(new Point(0, 0), 5);
		Circle c2 = new Circle(new Point(-7, 2), 42);

		File file = new File("circles.ser");

		try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file))) {

			out.writeObject(c1);

			c1.move(2, 4);

			out.reset();
			/*
			 * A kiíráskor a Java okos akar lenni: ha kétszer ugyanazt az
			 * objektumot írjuk ki, mint esetünkben a c1-et, akkor ahelyett,
			 * hogy újra kiírná, csak egy hivatkozást tesz bele, hogy ez
			 * ugyanaz, mint amit már kiírtunk. Ez általában jó, mert helyet
			 * spórol, és az esetleges hivatkozási köröket is feloldja. Viszont
			 * ha két különböző állapotát akarjuk kiírni ugyanannak az
			 * objektumnak, akkor már bajban leszünk, mert akkor az eredményünk
			 * az lenne, hogy ugyanazt az értéket látjuk kétszer.
			 * 
			 * Emiatt kell a reset: minden, ami utána jön, garantáltan kiíródik
			 * az aktuális állapotában, még akkor is, ha már egyszer kiírtuk.
			 */
			
			out.writeObject(c1);
			
			out.writeObject(c2);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
			try {
				while (true) {
					Circle c = (Circle) in.readObject();
					System.out.println(c);
				}
			} catch (EOFException e) {
				// Fájl vége.
			}		
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}	

		
	}

}
