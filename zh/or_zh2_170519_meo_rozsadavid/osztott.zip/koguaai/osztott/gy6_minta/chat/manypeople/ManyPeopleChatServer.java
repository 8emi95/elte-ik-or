package chat.manypeople;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 * A chatszerver főosztálya. Két szálunk lesz: az egyik a főszál, mely
 * folyamatosan várakozni fog újabb kliensek érkezésére. A másik a kliensekkel
 * való kommunikációt folytatja majd le, sorban szóhoz juttatva őket.
 */
public class ManyPeopleChatServer implements Runnable {

	private final int port;

	/**
	 * Az adott körben még soron következő kliensek listája. Mivel ezt a
	 * változót mindkét szál használhatja, ezért szinkronizációval kell védeni.
	 */
	private List<ClientHandler> nextClients = new LinkedList<>();

	/**
	 * Az adott körben már szóhoz jutott kliensek listája. Mivel ezt a változót
	 * mindkét szál használhatja, ezért szinkronizációval kell védeni.
	 */
	private List<ClientHandler> previousClients = new LinkedList<>();

	/**
	 * Az üzenetek listája. Mivel ezt a változót mindkét szál használhatja,
	 * ezért szinkronizációval kell védeni.
	 */
	private List<String> messages = new ArrayList<>();

	/**
	 * Letárolja a portszámot, hogy a {@link run} metódus kiolvashassa azt.
	 */
	ManyPeopleChatServer(int port) {
		this.port = port;
	}

	@Override
	public void run() {
		try (ServerSocket server = new ServerSocket(port)) {
			acceptClients(server);
		} catch (IOException e) {
			System.err.println("Error in server startup.");
			e.printStackTrace();
		}
	}

	/**
	 * Egy végtelen ciklusban próbálkozik kapcsolatot létesíteni új kliensekkel.
	 */
	private void acceptClients(ServerSocket server) {
		System.out.println("Server: running and waiting for clients.");
		while (true) {
			Socket socket = null;
			try {
				socket = server.accept();
				new ClientHandler(socket).startCommunication();
			} catch (Exception e) {
				if (socket != null) {
					try {
						socket.close();
					} catch (IOException e2) {
						e2.printStackTrace();
					}
				}
				System.err.println("Server: error while connecting to client.");
				e.printStackTrace();
			}
		}
	}

	/*
	 * A következő metódusok synchronized kulcsszóval lettek ellátva. Ez annak a
	 * szintaktikai egyszerűsítése, mintha a metódus teljes tartalmát
	 * körbevennénk egy
	 * 
	 * synchronized (this) {
	 * 
	 * }
	 * 
	 * blokkal. Tehát ez mindig az aktuális objektumra (itt a szerver főosztály
	 * aktuális példánya) szinkronizálunk. A szerver adatait tároló három listát
	 * csak ezekben a metódusokban fogjuk elérni, így elérve a szálbiztonságot.
	 */

	/**
	 * Ellenőrzi a nevet, és hozzáadja a következő kliensek listájához, ha jó.
	 */
	private synchronized boolean addClient(String name, ClientHandler client) {
		if (name.trim().equals("") || name.equals("Server")) {
			return false;
		}
		for (ClientHandler other : previousClients) {
			if (other.name.equals(name)) {
				return false;
			}
		}
		for (ClientHandler other : nextClients) {
			if (other.name.equals(name)) {
				return false;
			}
		}
		// Megfelel a feltételeknek, létrehozhatjuk a klienst.

		if (nextClients.isEmpty() && previousClients.isEmpty()) {
			// Ha éppen mindkét lista üres, akkor nem fut a kommunikációért
			// felelős szál, tehát elindítjuk!
			new CommunicationThread().start();
		}

		nextClients.add(client);

		// Mindenkit tájékoztatunk a jövevényről.
		messages.add("Server: '" + name + "' connected.");

		return true;
	}

	/**
	 * Törli a klienst a listákból (bármelyikben is van).
	 */
	private synchronized void removeClient(ClientHandler client) {
		nextClients.remove(client);
		previousClients.remove(client);
	}

	/**
	 * Visszaadja a következő klienst.
	 */
	private synchronized ClientHandler nextClient() {
		// Ha már nincs több kliens az aktuális körben, újrakezdjük a kört!
		if (nextClients.isEmpty()) {
			// Ha már egyáltalán nincs kliensünk, nullal térünk vissza, és majd
			// leáll a szál.
			if (previousClients.isEmpty()) {
				return null;
			}

			nextClients = previousClients;
			previousClients = new LinkedList<>();
		}
		// Kivesszük a következőt, és lementjük korábbiként.
		ClientHandler next = nextClients.remove(0);
		previousClients.add(next);
		return next;
	}

	/**
	 * Kiküldi az üzeneteket az aktuálisan sorra kerülő kliensnek a megadott
	 * indextől, és visszaadja, hogy aktuálisan hány üzenet van a listában.
	 */
	private synchronized int printMessages(int fromIndex, PrintWriter pw) {
		int size = messages.size();
		for (int i = fromIndex; i < size; ++i) {
			pw.println(messages.get(i));
		}
		return size;
	}

	/**
	 * Bejegyez egy új üzenetet.
	 */
	private synchronized void addMessage(String msg) {
		messages.add(msg);
	}

	/**
	 * Szál a kommunikáció lefolytatására. Mivel belső osztály, ezért van egy
	 * implicit hivatkozása az őt tartalmazó szerverre, így például eléri annak
	 * metódusait.
	 */
	private class CommunicationThread extends Thread {

		@Override
		public void run() {
			while (true) {
				ClientHandler next = nextClient();
				if (next == null) {
					break;
				}
				if (!next.speak()) {
					removeClient(next);
				}
			}
		}

	}

	/**
	 * Osztály egy kliens kezeléséhez. Mivel belső osztály, ezért van egy
	 * implicit hivatkozása az őt tartalmazó szerverre, így például eléri annak
	 * {@link messages} mezőjét.
	 */
	private class ClientHandler {

		final Socket socket;
		final PrintWriter pw;
		final Scanner sc;
		String name;

		int index = 0;

		ClientHandler(Socket socket) throws IOException {
			this.socket = socket;
			pw = new PrintWriter(socket.getOutputStream());
			sc = new Scanner(socket.getInputStream());
		}

		void startCommunication() throws Exception {
			while (true) {
				if (!sc.hasNextLine()) {
					throw new Exception();
				}
				name = sc.nextLine();

				// Kis kiegészítés a feladathoz: csak értelmes nevet engedünk.
				if (!addClient(name, this)) {
					pw.println("not ok");
					pw.flush();
				} else {
					pw.println("ok");
					pw.flush();
					return;
				}
			}
		}

		/**
		 * Megpróbál elküldeni egy üzenetet a kliensnek, és visszaadja, hogy
		 * sikerrel járt-e. Hiba esetén bontja a kapcsolatot a klienssel.
		 */
		private boolean speak() {
			try {
				index = printMessages(index, pw);
				pw.println("write");
				pw.flush();
				if (sc.hasNextLine()) {
					String answer = name + ": " + sc.nextLine();
					addMessage(answer);
					return true;
				}

				System.out.println("Server: client '" + name + "' closed the connection.");
			} catch (Exception e) {
				System.err.println("Server: communication problem with client '" + name + "'.");
				e.printStackTrace();
			}
			// Ha a kliens bontotta a kapcsolatot vagy hiba lépett fel a
			// kommunikáció során, mi is lezárjuk a socketet, eltakarítunk
			// magunk után.

			try {
				socket.close();
				pw.close();
				sc.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

			return false;
		}

	}

	public static void main(String[] args) {
		new ManyPeopleChatServer(12345).run();
	}

}
