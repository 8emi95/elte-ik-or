package chat.twopeople;

import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

/**
 * A chatkliens főosztálya.
 */
public class TwoPeopleChatClient implements Runnable {

	private final String host;
	private final int port;

	/**
	 * Letárolja a hoszt nevét és a portszámot, hogy a {@link run} metódus
	 * kiolvashassa azokat.
	 */
	TwoPeopleChatClient(String host, int port) {
		this.host = host;
		this.port = port;
	}

	/**
	 * Létrehozza a kapcsolatot a szerverrel, elküldi a nevét, majd lefolytatja
	 * a kommunikációt.
	 */
	@Override
	public void run() {
		try (Socket client = new Socket(host, port);
				PrintWriter pw = new PrintWriter(client.getOutputStream());
				Scanner sc = new Scanner(client.getInputStream())) {

			Scanner console = new Scanner(System.in);

			// Név bekérése, átküldése.
			// Kis kiegészítés a feladathoz: csak értelmes nevet engedünk.
			String answer;
			do {
				System.out.print("Name: ");
				pw.println(console.nextLine());
				pw.flush();
				answer = sc.nextLine();
			} while (!"ok".equals(answer));

			System.out.println("Connected to server.");

			// Chatelés.
			while (sc.hasNextLine()) {
				System.out.println(sc.nextLine());
				System.out.print("> ");
				pw.println(console.nextLine());
				pw.flush();
			}

		} catch (Exception e) {
			System.err.println("Error while connecting to server.");
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		new TwoPeopleChatClient("localhost", 12345).run();;
	}

}
