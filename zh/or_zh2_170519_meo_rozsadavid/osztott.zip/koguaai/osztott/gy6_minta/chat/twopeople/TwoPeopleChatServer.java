package chat.twopeople;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 * A chatszerver főosztálya.
 */
public class TwoPeopleChatServer implements Runnable {

	private final int port;

	/**
	 * A message változó tárolja az éppen elküldeni kívánt üzenetet.
	 */
	private String message = null;

	/**
	 * Letárolja a portszámot, hogy a {@link run} metódus kiolvashassa azt.
	 */
	TwoPeopleChatServer(int port) {
		this.port = port;
	}

	@Override
	public void run() {
		try (ServerSocket server = new ServerSocket(port)) {
			handleClients(server);
		} catch (IOException e) {
			System.err.println("Error in server startup.");
			e.printStackTrace();
		}
	}

	/**
	 * Kommunikáció lefolytatása a kliensekkel.
	 */
	public void handleClients(ServerSocket server) {
		ClientHandler client1 = acceptClient(server);
		ClientHandler client2 = acceptClient(server);

		message = "start";
		while (true) {
			// Amíg nem sikerül elküldeni az üzenetet, lecseréljük a klienst
			// egy újra. Ilyenkor a 'message' még az utolsó valid üzenetet
			// tárolja, azt küldjük majd újra, hiszen csak sikeres üzenetváltás
			// esetén módosítjuk az értékét.

			while (!client1.speak()) {
				client1 = acceptClient(server);
			}
			while (!client2.speak()) {
				client2 = acceptClient(server);
			}
		}
	}

	/**
	 * Egy végtelen ciklusban próbálkozik addig, míg nem sikerül kapcsolatot
	 * felépítenie egy klienssel.
	 */
	private ClientHandler acceptClient(ServerSocket server) {
		while (true) {
			Socket socket = null;
			try {
				socket = server.accept();
				ClientHandler client = new ClientHandler(socket);
				client.startCommunication();
				return client;
			} catch (Exception e) {
				if (socket != null) {
					try {
						socket.close();
					} catch (IOException e2) {
						e2.printStackTrace();
					}
				}
				System.err.println("Server: error while connecting to client.");
				e.printStackTrace();
			}
		}
	}

	/**
	 * Osztály egy kliens kezeléséhez. Mivel belső osztály, ezért van egy
	 * implicit hivatkozása az őt tartalmazó szerverre, így például eléri annak
	 * {@link message} mezőjét.
	 */
	private class ClientHandler {

		final Socket socket;
		final PrintWriter pw;
		final Scanner sc;
		String name;

		ClientHandler(Socket socket) throws IOException {
			this.socket = socket;
			pw = new PrintWriter(socket.getOutputStream());
			sc = new Scanner(socket.getInputStream());
		}

		void startCommunication() throws Exception {
			while (true) {
				if (!sc.hasNextLine()) {
					throw new Exception();
				}
				name = sc.nextLine();

				// Kis kiegészítés a feladathoz: csak értelmes nevet engedünk.
				if (name.trim().equals("") || name.equals("Server")) {
					pw.println("not ok");
					pw.flush();
				} else {
					pw.println("ok");
					pw.flush();
					return;
				}
			}
		}

		/**
		 * Megpróbál elküldeni egy üzenetet a kliensnek, és visszaadja, hogy
		 * sikerrel járt-e. Hiba esetén bontja a kapcsolatot a klienssel.
		 */
		boolean speak() {
			try {
				pw.println(message);
				pw.flush();
				if (sc.hasNextLine()) {
					String answer = name + ": " + sc.nextLine();
					message = answer;
					return true;
				}

				System.out.println("Server: client '" + name + "' closed the connection.");
			} catch (Exception e) {
				System.err.println("Server: communication problem with client '" + name + "'.");
			}
			// Ha a kliens bontotta a kapcsolatot vagy hiba lépett fel a
			// kommunikáció során, mi is lezárjuk a socketet, eltakarítunk
			// magunk után.

			try {
				socket.close();
				pw.close();
				sc.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			return false;
		}

	}

	public static void main(String[] args) {
		new TwoPeopleChatServer(12345).run();
	}

}
