
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {
	public static void main(String[] args) throws IOException {
		final int port = 12345;

		try (ServerSocket ss = new ServerSocket(port)) {
			handleClient(ss);
		}
	}

	private static void handleClient(ServerSocket ss) throws IOException {
		try (Socket s = ss.accept();
				Scanner sc = new Scanner(s.getInputStream());
				PrintWriter pw = new PrintWriter(s.getOutputStream())) {

			while (sc.hasNextLine()) {
				String input = sc.nextLine();
				System.out.println(input);

				pw.println("Hello, client!");
				pw.flush();
			}
		}
	}
}
