

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client {
	public static void main(String[] args) throws IOException {
		final String hostname = "localhost";
		final int port = 12345;

		try (Socket s = new Socket(hostname, port);
				Scanner sc = new Scanner(s.getInputStream());
				PrintWriter pw = new PrintWriter(s.getOutputStream());) {
			pw.println("Hello, server!");
			pw.flush();

			if (sc.hasNextLine()) {
				String line = sc.nextLine();
				System.out.println(line);
			}
		}
	}
}
