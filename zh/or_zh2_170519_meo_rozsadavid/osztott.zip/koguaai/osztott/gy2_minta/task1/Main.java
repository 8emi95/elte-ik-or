package task1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		List<Point> points = readPointsFromFile("input1.txt");

		// final Point origo = new Point(0, 0);
		// Point farthest = points.get(0);
		//
		// for (int i = 1; i < points.size(); ++i) {
		// Point p = points.get(i);
		// if (p.distance(origo) > farthest.distance(origo)) {
		// farthest = p;
		// }
		// }

		final Point first = points.get(0);
		Point nearest = points.get(1);
		for (int i = 2; i < points.size(); ++i) {
			Point p = points.get(i);
			if (p.distance(first) < nearest.distance(first)) {
				nearest = p;
			}
		}

		System.out.println(nearest);
	}

	private static List<Point> readPointsFromArguments(String[] args) {
		List<Point> result = new ArrayList<>();
		for (int i = 1; i < args.length; i += 2) {
			try {
				double x = Double.parseDouble(args[i - 1]);
				double y = Double.parseDouble(args[i]);
				Point p = new Point(x, y);
				result.add(p);
			} catch (NumberFormatException e) {
				System.out.println("Wrong input! Not a number!");
			}
		}

		return result;
	}

	private static List<Point> readPointsFromStandardInput() {
		Scanner sc = new Scanner(System.in);
		return readPointsFromScanner(sc);
	}

	private static List<Point> readPointsFromFile(String filename) {
		File file = new File(filename);

		try (Scanner sc = new Scanner(file)) {
			return readPointsFromScanner(sc);
		} catch (FileNotFoundException e) {
			System.out.println("File not found!");
			return new ArrayList<>();
		}

		// Scanner sc = null;
		// try {
		// sc = new Scanner(file);
		// return readPointsFromScanner(sc);
		// } catch (FileNotFoundException e) {
		// System.out.println("File not found!");
		// return new ArrayList<>();
		// } finally {
		// if (sc != null) {
		// sc.close();
		// }
		// }
	}

	private static List<Point> readPointsFromScanner(Scanner sc) {
		List<Point> result = new ArrayList<>();
		while (sc.hasNextDouble()) {
			double x = sc.nextDouble();
			if (sc.hasNextDouble()) {
				double y = sc.nextDouble();
				Point p = new Point(x, y);
				result.add(p);
			}
		}
		return result;
	}

}
