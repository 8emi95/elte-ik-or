package task1;

public class Point {

	private final double x;
	private final double y;

	public Point(double x, double y) {
		this.x = x;
		this.y = y;
	}

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

	public double distance(Point other) {
		double diffX = x - other.x;
		double diffY = y - other.y;
		return Math.sqrt(diffX * diffX + diffY * diffY);
	}
	
	@Override
	public String toString() {
		return "(" + x + ", " + y + ")";
	}

}
