package task2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		List<String> input = readFromFile("input2.txt");
		
		for (String s : input) {
//			String changed = s.replaceAll("a+", "a");
//			System.out.print(changed + " ");
			
			StringBuilder builder = new StringBuilder();
			if (!s.isEmpty()) {
				builder.append(s.charAt(0));
			}
			for (int i = 1; i < s.length(); ++i) {
				boolean toSkip = s.charAt(i) == 'a' && s.charAt(i - 1) == 'a';
				if (!toSkip) {
					builder.append(s.charAt(i));
				}
			}
			
			System.out.print(builder.toString() + " ");
		}
		System.out.println();
		
	}

	private static List<String> readFromFile(String filename) {
		File file = new File(filename);

		try (Scanner sc = new Scanner(file)) {
			List<String> result = new ArrayList<>();
			while (sc.hasNextLine()) {
				result.add(sc.nextLine());
			}
			return result;
		} catch (FileNotFoundException e) {
			System.out.println("File not found!");
			return new ArrayList<>();
		}
	}

}
