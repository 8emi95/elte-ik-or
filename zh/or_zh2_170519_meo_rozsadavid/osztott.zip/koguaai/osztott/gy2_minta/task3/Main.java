package task3;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		List<String> input = readFromFile("input3.txt");
		
		List<Person> people = new ArrayList<>();
		for (int i = 1; i < input.size(); i+=2) {
			Person p = new Person(input.get(i - 1), input.get(i));
			people.add(p);			
		}
		
		Map<String, List<Person>> groupedByName = new HashMap<>();
		
		for (Person p : people) {
			List<Person> list = groupedByName.get(p.getLastName());		
			if (list == null) {
				list = new ArrayList<>();
				groupedByName.put(p.getLastName(), list);
			}
			list.add(p);
		}
		
		for (List<Person> list : groupedByName.values()) {
			for (Person p : list) {
				System.out.println(p);
			}
			System.out.println();
		}
		
	}

	private static List<String> readFromFile(String filename) {
		File file = new File(filename);

		try (Scanner sc = new Scanner(file)) {
			List<String> result = new ArrayList<>();
			while (sc.hasNextLine()) {
				result.add(sc.nextLine());
			}
			return result;
		} catch (FileNotFoundException e) {
			System.out.println("File not found!");
			return new ArrayList<>();
		}
	}

}
