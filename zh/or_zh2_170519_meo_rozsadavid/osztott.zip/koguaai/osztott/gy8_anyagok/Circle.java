package geometry;

public class Circle {

    private Point center;
    private int r;
    private Double area = null;

    public Circle(Point center, int r) {
        this.center = center;
        this.r = r;
    }

    public double getArea() {
        if (area == null) {
            area = new Double(r * r * Math.PI);
        }
        return area;
    }

    public void move(int dx, int dy) {
        center.move(dx, dy);
    }

	@Override
    public String toString() {
        return center + " r: " + r + " area: " + area;
    }

}