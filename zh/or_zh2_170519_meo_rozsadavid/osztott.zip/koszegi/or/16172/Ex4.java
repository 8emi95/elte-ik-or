// Készíts egy 3 szálú alkalmazást! Legyen egy termelő, és két fogyasztó szálunk. Az termelő szál induljon el, és töltsön fel egy kollekciót 10 db véletlen számmal (a másik két szál indulás után várjon)! Ezután jelezzen a másik két szálnak (wait(), notify()), hogy elkezdhetik a számok feldolgozását: adják össze őket. Az eredeti szál várja be a feldolgozást, majd írja ki a részösszegek összegét!

import java.util.*;

// https://github.com/rlegendi/ELTE-javagyak/blob/master/15-threading-alapok/15-threading-alapok.md
// 4. feladat (a végén nem a termelő várja az eredményeket, hanem a főszál)
public class Ex4 {

    static volatile boolean kesz = false;

    static class Termelo extends Thread {

        int n;

        public Termelo(int n) {
            this.n = n;
        }

        @Override
        public void run() {
            Random r = new Random();
            for (int i=0; i<n;  i++) {
                l.add(r.nextInt(100));
            }
            synchronized(monitor) {
                kesz = true;
                monitor.notifyAll();
            }
        }
    }

    static class Fogyaszto extends Thread {

        public Fogyaszto(int tol, int ig) {
            this.tol = tol;
            this.ig = ig;
        }

        int tol, ig;
        int sum = 0;
        @Override
            public void run() {
            if (!kesz) {
                try {
                    synchronized(monitor) {
                        monitor.wait();
                    }
                } catch (Exception e) {e.printStackTrace();}
            }
            for (int i=tol; i<ig; i++) {
                sum += l.get(i);
            }
            System.out.println(this.getName() + ": " + sum);
        }
    }


    static List<Integer> l = new ArrayList<Integer>();
    static Object monitor = new Object();

    public static void main(String[] args) throws InterruptedException {

        Termelo t = new Termelo(10);
        Fogyaszto f1 = new Fogyaszto(0,5);
        Fogyaszto f2 = new Fogyaszto(5,10);
        t.start(); f1.start(); f2.start();
        f1.join(); f2.join();
        System.out.println(f1.sum + f2.sum);

    }
}
