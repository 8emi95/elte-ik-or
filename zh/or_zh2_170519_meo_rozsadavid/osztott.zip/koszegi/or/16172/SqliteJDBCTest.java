import java.sql.*;

public class SqliteJDBCTest {

    public static void main(String[] args) throws Exception {
    
        //adatbazis letrehozasa
        Class.forName("org.sqlite.JDBC");
        Connection conn = DriverManager.getConnection("jdbc:sqlite:test.db");
        System.out.println("adatbazis letrehozva");
        
        //tabla letrehozasa
        Statement stat = conn.createStatement();
        
        stat.executeUpdate("drop table if exists people;");
        String sql = "CREATE TABLE if not exists people (" +
                     "name       CHAR(50) NOT NULL, " + 
                     "occupation CHAR(50));";
        stat.executeUpdate(sql);
        System.out.println("tabla letrehozva");
        
        //tabla feltolese 1.0
        sql = "INSERT INTO people (name, occupation) VALUES ('Kitlei Robert', 'teacher');"; 
        stat.executeUpdate(sql);
        
        //feltoltes 2.0    
        PreparedStatement prep = conn.prepareStatement("insert into people (name, occupation) values (?, ?);");
        prep.setString(1, "Nev2");  prep.setString(2, "occ2");   prep.addBatch();
        prep.setString(1, "Nev3");  prep.setString(2, "occ3");   prep.addBatch();
        prep.setString(1, "Nev4");  prep.setString(2, "occ4");   prep.addBatch();
        prep.executeBatch();
        
        //lekerdezes
        ResultSet rs = stat.executeQuery("select * from people;");
        while (rs.next()) {
            System.out.println("name = " + rs.getString("name"));
            System.out.println("job = " + rs.getString("occupation"));
        }
        rs.close();
        
        //lezaras
        stat.close();
        conn.close();
    }
}
