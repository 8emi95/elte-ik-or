//Készíts 5 szálat, amelyek egy saját csoportban vannak! A szálak egy véletlen számot választanak az [1..100] intervallumból, és fél másodpercenként növelnek egy saját számlálót ezzel az értékkel, amíg az meg nem haladja az 1000-et.

import java.util.*;

// https://github.com/rlegendi/ELTE-javagyak/blob/master/15-threading-alapok/15-threading-alapok.md
//7-es feladat, vége egyszerűsítve
public class Ex7 {

    public static ThreadGroup tg = new ThreadGroup("myGroup");

    public static void printActiveThreads() {
        Thread[] threads = new Thread[tg.activeCount()];
        tg.enumerate(threads, false);
        for (Thread t : threads) {
            if (t != null) {
                System.out.print(t.getName() + " ");
            }
        }
        System.out.println();

    }

    public static void main(String[] args) throws InterruptedException {
        for (int i=0; i<5; i++) {
            Thread t = new Thread(tg, new Thread() {

                    @Override
                    public void run() {
                        int counter = 0;
                        int random = (new Random()).nextInt(50)+51;
                        while(counter < 1000) {
                            //System.out.println(this.getName() + ":" + counter);
                            try {
                                Thread.sleep(500);
                            } catch (InterruptedException e) {}
                            counter += random;
                        }
                    }
                });
            t.start();
        }

        while(tg.activeCount() > 0) {
            printActiveThreads();
            Thread.sleep(2000);
        }

    }
}
