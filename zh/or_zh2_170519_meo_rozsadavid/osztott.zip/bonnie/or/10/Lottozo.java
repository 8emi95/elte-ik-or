import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.util.*;

public class Lottozo extends UnicastRemoteObject implements LottozoInterface{

    public static final int DB = 5;
    public static final int MAX = 90;
    public static final int DIJ = -2;
    public static final int NYEREMENY = 5;
    public static final String CSOD = "Csodbe ment a lottozo.";

    private int kassza;

    private Set<Integer> nyeroszamok = new HashSet<Integer>();
 
    private Random rand = new Random(123456);

    public Lottozo(int kassza) throws RemoteException {
        this.kassza = kassza;
    }

    public synchronized void sorsol() throws RemoteException {
        if (kassza <= 0) throw new UnsupportedOperationException(CSOD);

        nyeroszamok.clear();
        while (nyeroszamok.size() < 5) {
            nyeroszamok.add(rand.nextInt(MAX) + 1);
        } 
        log("sorsolas: " + nyeroszamok);
    }

    public synchronized int jatszik(Set<Integer> szamok) throws RemoteException {
        if (kassza <= 0) throw new UnsupportedOperationException(CSOD);

        int nyeremeny = DIJ;
        int talalat = 0;
        for (int szam : szamok) {
             if (nyeroszamok.contains(szam)) talalat++;
        }
        if (talalat >= 2) nyeremeny += talalat * NYEREMENY;
        kassza -= nyeremeny;
        
        log("tipp: " + szamok + "; kifizetes: " + nyeremeny + "; uj kassza: " + kassza);

        if (kassza <= 0) throw new UnsupportedOperationException(CSOD);

        return nyeremeny;
    }
    
    private void log(String szoveg) {
        System.out.println("L> " + szoveg);
    }

    public static void main(String[] args) throws Exception {
        Registry registry = LocateRegistry.createRegistry(8899);

        Lottozo l = new Lottozo(Integer.parseInt(args[0]));
        registry.rebind("lottozo", l);
    }
}
