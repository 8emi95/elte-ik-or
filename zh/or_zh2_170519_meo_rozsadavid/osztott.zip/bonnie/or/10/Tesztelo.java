class Tesztelo {
    public static final int VARAKOZAS = 1000;
    
    public static void main(String[] args) throws Exception {
        Lottozo.main(new String[]{"20"});
        try { Thread.sleep(VARAKOZAS); } catch (InterruptedException e) {}
        
        new Thread(() -> {
            try { Sorsolo.main(new String[0]); } catch( Exception e ) { }
        }).start();
        try { Thread.sleep(VARAKOZAS/2); } catch (InterruptedException e) {}
        
        Ember.main(new String[]{"Pista", "10", "input.txt"});
    }
}
