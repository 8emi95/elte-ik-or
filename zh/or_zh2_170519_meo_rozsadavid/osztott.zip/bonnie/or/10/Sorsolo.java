import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;

public class Sorsolo {
    
    LottozoInterface lottozo;
    
    public final int VARAKOZAS = 1000;

    public Sorsolo(LottozoInterface lottozo) {
        this.lottozo = lottozo;
    }

    public void sorsolgat() throws Exception {
        while (true) {
            try { 
                lottozo.sorsol();
            } catch (UnsupportedOperationException e) {break;}
            try {
                Thread.sleep(VARAKOZAS);
            } catch (InterruptedException e) {}
        }    
    }

    public static void main(String[] args) throws Exception {
        Registry registry = LocateRegistry.getRegistry("localhost", 8899);        
        LottozoInterface lottozo = (LottozoInterface) (registry.lookup("lottozo"));

        Sorsolo s = new Sorsolo(lottozo);
        s.sorsolgat();
    }
}
