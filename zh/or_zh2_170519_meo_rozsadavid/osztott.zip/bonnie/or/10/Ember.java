import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;
import java.util.*;
import java.io.*;

public class Ember {

    private LottozoInterface lottozo;
    private String nev;
    private int penz;
    Scanner tippolvaso;

    public final int VARAKOZAS = 1000;
    public final int DIJ = 2;
    public static final int DB = 5;
   
    public Ember(LottozoInterface lottozo, String nev, int penz, String fajlnev) throws IOException {
        this.lottozo = lottozo;
        this.nev = nev;
        this.penz = penz;
        tippolvaso = new Scanner(new File(fajlnev));
    }

    private void log(String szoveg) {
        System.out.println(nev + "> " + szoveg);
    }

    public void jatszik() throws IOException {
        while (penz >= DIJ) {
            Set<Integer> tipp = new HashSet<Integer>();
            for (int i=0; i<DB; i++) {
                tipp.add(tippolvaso.nextInt());   
            }
            try {
                int nyeremeny = lottozo.jatszik(tipp);
                penz += nyeremeny;
                log("tipp: " + tipp + "; kifizetes: " + nyeremeny + "; penzem: " + penz);
                try {
                    Thread.sleep(VARAKOZAS);
                } catch (InterruptedException e) {}
            } catch (UnsupportedOperationException e) {
                log("A lottozas befejezodott, mert a lottozo csodbe ment.");
                break;
            }
        }
        if (penz < DIJ) log("A lottozas befejezodott, mert elfogyott a penzem.");
    } 
   
    public static void main(String[] args) throws Exception {
        Registry registry = LocateRegistry.getRegistry("localhost", 8899);        
        LottozoInterface lottozo = (LottozoInterface) (registry.lookup("lottozo"));
        
        Ember ember = new Ember(lottozo, args[0], Integer.parseInt(args[1]), args[2]);
        ember.jatszik();
    }
}
