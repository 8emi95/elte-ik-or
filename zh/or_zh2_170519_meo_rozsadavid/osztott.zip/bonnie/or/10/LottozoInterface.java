import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.*;

public interface LottozoInterface extends Remote {
    void sorsol() throws RemoteException;
    int jatszik(Set<Integer> szamok) throws RemoteException;
}
