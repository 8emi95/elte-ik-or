import java.io.Serializable;

public class Circle implements Serializable {

    static final long serialVersionUID = 42L;
    public static double pi = Math.PI;
    
    private Point cp;
    private int r;
    transient private Double area = null;

    public Circle(Point cp, int r) {
        this.cp = cp;
        this.r = r;
    }

    public double getArea() {
        if (area == null) {
            System.out.println("szamolom...");
            area = new Double(r * r * pi);
        }
        return area;
    }

    public String toString() {
        return cp + " r: " + r + " area: " + area;
    }

    public void move(int dx, int dy) {
        cp.move(dx, dy);
    }
}