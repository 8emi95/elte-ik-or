import java.io.ObjectOutputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.FileInputStream;

class Main {

    static final String filename = "circles.ser";
    
    public static void main(String[] args) throws Exception {
        
        Circle circle1 = new Circle(new Point(0,0), 3);
        Circle circle2 = new Circle(new Point(1,1), 5);
        
        System.out.println(circle2);
        System.out.println(circle2.getArea());
        System.out.println(circle2);
        
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename));
        oos.writeObject(circle1);
        circle1.move(2,4);
        oos.reset();  //szukseges, ha ugyanazt (de mar megvaltozott) objektumot irjuk ki ujra
        oos.writeObject(circle1);
        oos.writeObject(circle2);
        oos.close();
        
        System.out.println("\n-------------------\n");
        
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename));
        
        System.out.println(ois.readObject());
        System.out.println(ois.readObject());
        System.out.println(ois.readObject());
    }
}