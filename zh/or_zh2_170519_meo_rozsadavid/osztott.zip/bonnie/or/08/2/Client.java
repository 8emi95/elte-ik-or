import java.net.Socket;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

class Client {

    public static void main(String[] args) {
        try (
            Socket s = new Socket("localhost", 12345);
            
            //mindig oos eloszor!
            ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
            ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
        ) {
            Circle c = new Circle(new Point(1,2), 3);
            System.out.println("pont letrehozva letrehozva: " + c);
            
            oos.writeObject(c);
            System.out.println("atkuldtem...");
            
            double d = (Double) ois.readObject();
            System.out.println("Megkaptam: " + d);
            
        } catch(Exception e) {
            System.err.println(e);
            e.printStackTrace();
        }
        System.out.println("lezartam...");
    }
}