import java.net.ServerSocket;
import java.net.Socket;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

class Server {

    public static void main(String[] args) {
        try (
            ServerSocket ss = new ServerSocket(12345);
            Socket s = ss.accept();
            
            //mindig oos eloszor!
            ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
            ObjectInputStream ois = new ObjectInputStream(s.getInputStream());
        ) {
            Circle c = (Circle) ois.readObject();
            System.out.println("megkaptam: " + c);
            
            //System.out.println(c.getArea());
            
            oos.writeObject(c.getArea());
            System.out.println("visszakuldtem...");
        
        } catch(Exception e) {
            System.err.println(e);
            e.printStackTrace();
        }
        System.out.println("lezartam...");
    }
}
