import java.util.Random;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.FileOutputStream;

class NumberWriter {
    static final int count = 10;
    static final String filename = "numbers.ser";
    
    public static void main(String[] args) throws IOException {
    
        Random rand = new Random();
        ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename));
        
        for( int j = 0; j < count; ++j ) {
            if( rand.nextBoolean() ) {
                //int
                Integer intNumber = rand.nextInt();
                System.out.println("int: " + intNumber);
                oos.writeObject(intNumber);
                oos.flush();
            }
            else {
                //double
                Double doubleNumber = rand.nextDouble();
                System.out.println("double: " + doubleNumber);
                oos.writeObject(doubleNumber);
                oos.flush();
            }
        }
        
        oos.close();
    }
}
