import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.FileInputStream;

class NumberReader {
    static final int count = 10;
    static final String filename = "numbers.ser";
    
    public static void main(String[] args) throws Exception {
    
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename));
        
        int sumInteger = 0;
        double sumDouble = 0;
        int countInteger = 0;
        int countDouble = 0;
        
        for( int j = 0; j < count; ++j ) {
            Object number = ois.readObject();
            //System.out.println("beolavastam egy " + number.getClass() + " tipusu objektumot");
            
            if( number instanceof Integer) {
                //int
                Integer intNumber = (Integer)number;
                System.out.println("int: " + intNumber);
                countInteger++;
                sumInteger += intNumber;
            }
            
            if( number instanceof Double) {
                //double
                Double doubleNumber = (Double)number;
                System.out.println("double: " + doubleNumber);
                countDouble++;
                sumDouble += doubleNumber;
            }
        }
        
        System.out.println("count of Integers: " + countInteger + ", sum of Integers: " + sumInteger);
        System.out.println("count of Doubles: " + countDouble + ", sum of Doubles: " + sumDouble);
    }
}
