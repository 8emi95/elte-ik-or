import java.net.*;
import java.io.*;
import java.util.*;

public class ChatClient {
    
    public static volatile boolean serverExit = false;
    //volatile: garantalja, hogy a szalak nem cache-elik az adott valtozo erteket, hanem mindig a frissitik
    
    ChatClient(String host, int port) {
        try {
            Socket client = new Socket(host, port);
            PrintWriter pw = new PrintWriter(client.getOutputStream(), true);
            Scanner sc = new Scanner(client.getInputStream());
            
            Scanner scIn = new Scanner(System.in);
            
            //nev bekerese, atkuldese
            String answer = "";
            while( !"ok".equals(answer) ) {
                System.out.print("Nev: ");
                pw.println(scIn.nextLine());
                answer = sc.nextLine();
            }
            
            System.out.println("Sikeresen csatlakoztal.");
            
            //ket szal elinditasa parhuzamosan
            (new KuldoSzal(pw, scIn)).start();
            (new FogadoSzal(sc)).start();
            
        } catch (Exception e) {
            System.err.println("Nem sikerult kapcsolodni a szerverhez.");
            e.printStackTrace();
            return;
        }
    }
    
    public static void main(String[] args) {
        new ChatClient("localhost", 12345);
    }
}

//olvassa a standard inputot (billentyuzet), es tovabbkuldi a szervernek
class KuldoSzal extends Thread {
    PrintWriter pw;
    Scanner sc;
    
    KuldoSzal(PrintWriter pw, Scanner sc) {
        this.pw = pw;
        this.sc = sc;
    }
    
    @Override
    public void run() {
        try{        
            String message = "";
            while( !ChatClient.serverExit && !message.equals("!exit") ) {
                message = sc.nextLine();
                pw.println(message);
            }
            pw.close();
        } catch(Exception e) {
            System.err.println("Hiba a kuldo szalban.");
            e.printStackTrace();
        }
    }
}

//fogadja a szervertol erkezo sorokat, es kiirja a kepernyore
class FogadoSzal extends Thread {
    Scanner sc;
    
    FogadoSzal(Scanner sc) {
        this.sc = sc;
    }
    
    @Override
    public void run() {
        while( sc.hasNextLine() ) {
            System.out.println(sc.nextLine());
        }
        System.out.println("A szerver lezarta a kapcsolatot");
        //jelzes a masik szalnak
        ChatClient.serverExit = true;
    }
}
