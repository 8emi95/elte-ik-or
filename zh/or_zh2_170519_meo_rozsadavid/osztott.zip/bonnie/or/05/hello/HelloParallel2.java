//szal inditasa Runnable interfesszel

public class HelloParallel2 {
    public static void main(String[] args) {
        new Thread(new Hello()).start();
                
        //alternativ megoldas: lambda fuggvennyel
        
        //elso valtozat
        //Runnable task = () -> { for( int i = 0; i < 100; ++i ) System.out.print("Hello World! "); };
        //new Thread(task).start();
        
        //masodik valtozat
        //new Thread(() -> { for( int i = 0; i < 100; ++i ) System.out.print("Hello World! "); }).start();
    }
}

class Hello implements Runnable {
    @Override
    public void run() {
        for( int i = 0; i < 100; ++i )
            System.out.print("Hello World! ");
    }
}
