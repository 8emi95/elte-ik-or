import java.net.*;
import java.io.*;
import java.util.Scanner;

public class Client {
   
    public static void main(String[] args) throws IOException {
        Socket s = new Socket("localhost", Server.PORT);
        
        PrintWriter pw = new PrintWriter(s.getOutputStream(), true);
        Scanner sc = new Scanner(s.getInputStream());
        
        for (int i = 10; i >= 0; i--) {
            pw.println(i);
            System.out.println("Visszakaptam: " + sc.nextLine());
        }        
        
        pw.close();
        s.close();
    }
}
