import java.net.Socket;
import java.util.Scanner;
import java.io.PrintWriter;

public class Kliens {
    public static void main(String[] args) throws Exception {
        final String GEP = "localhost";
        final int PORT = 12345;
        
        //try-with-resources
        try (
            Socket s = new Socket(GEP, PORT);
            
            PrintWriter pw = new PrintWriter(s.getOutputStream(), true);  //true => autoFlush println, printf, format eseten
            Scanner sc = new Scanner(s.getInputStream());
        ) {
            pw.println("abc");
      
            String valasz = sc.nextLine();
            System.out.println(valasz);
        }
    }
}
