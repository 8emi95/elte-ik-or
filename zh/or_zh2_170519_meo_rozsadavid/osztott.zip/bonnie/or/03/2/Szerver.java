import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import java.io.PrintWriter;

public class Szerver {

    public static void main(String[] args) throws Exception {
        final int PORT = 12345;
        
        //try-with-resources
        try (
            ServerSocket ss = new ServerSocket(PORT);
            Socket s = ss.accept();
            
            PrintWriter pw = new PrintWriter(s.getOutputStream(), true);  //true => autoFlush println, printf, format eseten
            Scanner sc = new Scanner(s.getInputStream());
        ) {
            String sor = sc.nextLine();
            System.out.println("Fogadtam: " + sor);
                
            pw.println(sor);
        }
    }
}
