import java.net.Socket;
import java.util.Scanner;
import java.io.PrintWriter;

public class Kliens {
    public static void main(String[] args) throws Exception {
        final String GEP = "localhost";
        final int PORT = 12345;
        
        try (
            Socket s = new Socket(GEP, PORT);
            
            PrintWriter pw = new PrintWriter(s.getOutputStream(), true);
            Scanner sc = new Scanner(s.getInputStream());
        ) {
            long startTime = System.currentTimeMillis();
            
            pw.println("abc");
            
            while( sc.hasNext() ) {
                System.out.print(sc.nextLine() + "*");
            }
            
            long endTime = System.currentTimeMillis();
            
            System.out.println(endTime-startTime);
        }
    }
}
