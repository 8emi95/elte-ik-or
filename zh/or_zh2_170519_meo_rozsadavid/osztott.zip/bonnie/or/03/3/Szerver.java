import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import java.io.PrintWriter;

public class Szerver {
    public static void main(String[] args) throws Exception {
        final int PORT = 12345;
        int ismetlesSzam = Integer.parseInt(args[0]);
        
        try (
            ServerSocket ss = new ServerSocket(PORT);
            Socket s = ss.accept();
            
            PrintWriter pw = new PrintWriter(s.getOutputStream(), true);
            Scanner sc = new Scanner(s.getInputStream());
        ) {
            String sor = sc.nextLine();
            
            /*
            //a/i). 100 000 adatra: 40mp; 1 000 000 adatra: >2ora
            String valasz = "";
            for( int i = 0; i < ismetlesSzam; ++i ) {
                valasz += sor;
            }
            pw.println(valasz);
            */
            
            /*
            //a/ii). 100 000 adatra: 1mp; 1 000 000 adatra: 12mp; 5 000 000 adatra: 1p6mp
            StringBuilder valasz = new StringBuilder();
            for( int i = 0; i < ismetlesSzam; ++i ) {
                valasz.append(sor);
            }
            pw.println(valasz.toString());
            */
            
            /*
            //a/iii). 100 000 adatra: 1mp; 1 000 000 adatra: 13mp; 5 000 000 adatra: 1p29mp
            for( int i = 0; i < ismetlesSzam; ++i ) {
                pw.print(sor);
            }
            pw.println();
            //pw.flush();  //a flush hivasa nem szukseges, a println utan automatikusan meghivodik (ld. PrintWriter letrehozasaban a true)
            */
            
            //b). 100 000 adatra: 6mp; 1 000 000 adatra: 1p8mp (localhost)
            for( int i = 0; i < ismetlesSzam; ++i ) {
                pw.println(sor);
            }
        }
    }
}
