import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Szerver {
    public static void main(String[] args) throws Exception {
        
        final int PORT = Integer.parseInt(args[0]);
        
        ServerSocket ss = new ServerSocket(PORT);
        Socket s = ss.accept();  //blokkolodik kapcsolodasig
            
        Scanner sc = new Scanner(s.getInputStream());
        
        String sor = sc.nextLine();  //blokkolodik adatfogadasig
        System.out.println("Fogadtam: " + sor);
            
        sc.close();
        s.close();
        ss.close();
    }
}
