import java.net.Socket;
import java.io.PrintWriter;

public class Kliens {
    public static void main(String[] args) throws Exception {
        final String GEP = "localhost";
        final int PORT = Integer.parseInt(args[0]);
        
        Socket s = new Socket(GEP, PORT);
        
        PrintWriter pw = new PrintWriter(s.getOutputStream());
        
        pw.println("abc");
        pw.flush();
        
        pw.close();
        s.close();
    }
}
