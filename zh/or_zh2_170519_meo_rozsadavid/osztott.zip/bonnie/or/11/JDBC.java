import java.sql.*;
import java.util.*;

public class JDBC {

    private static Scanner scIn = new Scanner(System.in);
    
    private Connection conn;
    private Statement stat;
    
    private JDBC(String databaseName) throws Exception {
        
        //adatbazis megnyitasa
        Class.forName("org.hsqldb.jdbc.JDBCDriver");
        conn = DriverManager.getConnection("jdbc:hsqldb:file:" + databaseName);
        stat = conn.createStatement();
        
        //tabla letrehozasa
        stat.executeUpdate("CREATE TABLE IF NOT EXISTS raktar (id INTEGER IDENTITY PRIMARY KEY, nev VARCHAR(50) NOT NULL, ar INTEGER);");
    }
    
    private String readString(String question) {
        String answer;
        
        do {
            System.out.print(question + ": ");
            answer = scIn.nextLine().trim();
        } while( answer.equals("") );
        
        return answer;
    }
    
    private int readInt(String question) {
        int answer;
        
        System.out.print(question + ": ");
        while( !scIn.hasNextInt() ) {
            scIn.next();
            System.out.print(question + ": ");
        }
        answer = scIn.nextInt();
        scIn.nextLine();  //enter beolvasasa
        
        return answer;
    }
    
    //tabla feltolese
    private void insert() throws Exception {
        PreparedStatement prep = conn.prepareStatement("insert into raktar (nev, ar) values (?, ?);");
        
        prep.setString(1, readString("Nev"));
        prep.setInt(2, readInt("Ar"));
        prep.executeUpdate();
    }
    
    //modositas
    private void update() throws Exception {
        PreparedStatement prep = conn.prepareStatement("update raktar set nev = ?, ar = ? where ID = ?;");
        
        prep.setInt(3, readInt("Azonosito"));
        prep.setString(1, readString("Uj nev"));
        prep.setInt(2, readInt("Uj ar"));
        prep.executeUpdate();
    }
    
    //torles
    private void delete() throws Exception {
        PreparedStatement prep = conn.prepareStatement("delete from raktar where ID = ?;");
        
        prep.setInt(1, readInt("Azonosito"));
        prep.executeUpdate();
    }
    
    //lekerdezes
    private void select() throws Exception {
        System.out.println();
        ResultSet rs = stat.executeQuery("select * from raktar;");
        while (rs.next())
            System.out.println("azonosito: " + rs.getInt("id") + ", nev: " + rs.getString("nev") + ", ar: " + rs.getString("ar"));
        rs.close();
        System.out.println();
    }
    
    //lezaras
    private void close() throws Exception {
        stat.close();
        conn.close();
    }
    
    public static void main(String[] args) throws Exception {
        JDBC database = new JDBC("raktar.db");
        
        boolean kilep = false;
        
        do {
            System.out.println("1 - beszuras | 2 - modositas | 3 - torles | 4 - lekerdezes | 5 - kilepes");
            
            switch( scIn.nextLine() ) {
                case "1": database.insert(); break;
                case "2": database.update(); break;
                case "3": database.delete(); break;
                case "4": database.select(); break;
                case "5": kilep = true; break;
                default: System.out.println("hibas valasztas");
            }
        } while(!kilep);
        
        database.close();
    }
}
