import java.sql.*;

public class JDBCTest {

    public static void main(String[] args) throws Exception {
    
        //osztaly betoltese 
        Class.forName("org.hsqldb.jdbc.JDBCDriver");
        
        //adatbazis letrehozasa
        Connection conn = DriverManager.getConnection("jdbc:hsqldb:file:test.db");
        //vagy: Connection conn = DriverManager.getConnection("jdbc:hsqldb:file:test.db", username, password);
        
        System.out.println("adatbazis letrehozva");
        
        //tabla letrehozasa
        Statement stat = conn.createStatement();
        
        stat.executeUpdate("drop table if exists raktar;");
        String sql = "CREATE TABLE raktar (" +
                     "nev VARCHAR(50) NOT NULL, " + 
                     "ar  INTEGER     NOT NULL);";
        stat.executeUpdate(sql);
        System.out.println("tabla letrehozva");
        
        //tabla feltolese 1.0
        sql = "INSERT INTO raktar (nev, ar) VALUES ('alma', 200);"; 
        stat.executeUpdate(sql);
        
        //feltoltes 2.0
        PreparedStatement prep = conn.prepareStatement("insert into raktar (nev, ar) values (?, ?);");
        prep.setString(1, "korte");  prep.setInt(2, 350); prep.addBatch();
        prep.setString(1, "barack"); prep.setInt(2, 150); prep.addBatch();
        prep.executeBatch();
        
        //lekerdezes
        ResultSet rs = stat.executeQuery("select * from raktar;");
        while (rs.next()) {
            System.out.println(rs.getString("nev") + ": " + rs.getInt("ar") + " Ft");
        }
        rs.close();
        
        //lezaras
        stat.close();
        conn.close();
    }
}
