import java.net.*;
import java.util.*;
import java.io.*;

class VegtelenSzerver {
    public static void main(String[] args) throws IOException {
        Random r = new Random();
        final int port = 12345;
        
        try ( ServerSocket ss = new ServerSocket(port) ) {
        
            boolean alljonLeASzerver = false;
            while( !alljonLeASzerver ) { 
                int szam = r.nextInt(100)+1;
                System.out.println("A gondolt szam: " + szam);
                
                try (
                    Socket s = ss.accept();
                    
                    PrintWriter pw = new PrintWriter(s.getOutputStream(), true);
                    Scanner sc = new Scanner(s.getInputStream());
                ) {
                    boolean talalt = false;
                    while( !talalt && !alljonLeASzerver ) { 
                        String tipp = sc.next();  //ha megszakadt a kapcsolat: NoSuchElementException
                        
                        if( tipp.equals("!leall") ) {
                            System.out.println("A kliens keresere a szerver leall.");
                            alljonLeASzerver = true;
                        }
                        else {
                            int iTipp = Integer.parseInt(tipp);
                            System.out.println("Kliens tippe: " + iTipp);
                            
                            if( iTipp < szam ) {
                                pw.println("nagyobb");  //a gondolt szam ennel nagyobb
                            }
                            else if( iTipp > szam ) {  //a gondolt szam ennel kisebb
                                pw.println("kisebb");
                            }
                            else {
                                pw.println("talalt");
                                System.out.println("Az aktualis klienssel a jatek befejezodott, a szerver uj kliensre var.");
                                talalt = true;
                            }
                        }
                    }
                } catch( IOException | NoSuchElementException e ) {
                    System.out.println("Az aktualis klienssel megszakadt a kapcsolat, a szerver uj kliensre var.");
                }
            }
        }
    }
}
