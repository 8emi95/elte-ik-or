import java.net.*;
import java.util.*;
import java.io.*;

class ManualKliens {
    public static void main(String[] args) throws IOException {
        final String gep = "localhost";
        final int port = 12345;
        
        try (
            Socket s = new Socket(gep, port);
            
            PrintWriter pw = new PrintWriter(s.getOutputStream(), true);
            Scanner sc = new Scanner(s.getInputStream());
            Scanner scIn = new Scanner(System.in);
        ) {
            boolean talalt = false;
            boolean kilep = false;
            
            while( !talalt && !kilep ) {
                System.out.println("Kerem a tippet!");
                
                while( !kilep && !scIn.hasNextInt() ) {
                    if ( scIn.next().equals("!leall") ) {
                        pw.println("!leall");
                        kilep = true;
                    }
                    else {
                        System.out.println("Hibas input");
                        System.out.println("Kerem a tippet!");
                    }
                }
                
                if( !kilep ) {
                    int tipp = scIn.nextInt();
                    pw.println(tipp);
                  
                    String valasz = sc.nextLine();
                    if( valasz.equals("nagyobb") ) {
                      System.out.println("Nem nyert - a gondolt szam ennel nagyobb.");
                    }
                    else if( valasz.equals("kisebb") ) {
                      System.out.println("Nem nyert - a gondolt szam ennel kisebb.");
                    }
                    else if( valasz.equals("talalt") ) {
                      System.out.println("Gratulalok, eltalaltad!");
                      talalt = true;
                    }
                }
            }
        }
    }
}
