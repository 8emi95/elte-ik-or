import java.net.*;
import java.util.*;
import java.io.*;

class AutomaticKliens {
    public static void main(String[] args) throws IOException {
        final String gep = "localhost";
        final int port = 12345;
        
        try (
            Socket s = new Socket(gep, port);
            
            PrintWriter pw = new PrintWriter(s.getOutputStream(), true);
            Scanner sc = new Scanner(s.getInputStream());
        ) {
            int also  = 1;
            int felso = 100;
            boolean talalt = false;
            
            Random r = new Random();
            
            while (!talalt) {
                /*
                //az adott intervallumban veletlenszeruen tippel
                int tipp = r.nextInt(felso-also+1)+also;
                */
                
                //az adott intervallumban celiranyosan tippel
                int tipp = (felso+also)/2;
                
                System.out.println("Automata tipp: " + tipp);
              
                pw.println(tipp);
              
                String valasz = sc.nextLine();
                if( valasz.equals("nagyobb") ) {
                  also = tipp + 1;
                }
                else if( valasz.equals("kisebb") ) {
                  felso = tipp - 1;
                }
                else if( valasz.equals("talalt") ) {
                  System.out.println("Eltalaltam, ugyes vagyok!");
                  talalt = true;
                }
            }
        }
    }
}
