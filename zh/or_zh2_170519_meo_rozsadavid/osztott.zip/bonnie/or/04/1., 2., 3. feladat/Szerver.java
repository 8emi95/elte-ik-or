import java.net.*;
import java.util.*;
import java.io.*;

class Szerver {
    public static void main(String[] args) throws IOException {
        Random r = new Random();
        int szam = r.nextInt(100)+1;
        System.out.println("A gondolt szam: " + szam);
        
        final int port = 12345;
        
        try (
            ServerSocket ss = new ServerSocket(port);
            Socket s = ss.accept();
            
            PrintWriter pw = new PrintWriter(s.getOutputStream(), true);
            Scanner sc = new Scanner(s.getInputStream());
        ) {
            boolean talalt = false;
            while( !talalt ) { 
                int tipp = sc.nextInt();
                System.out.println("Kliens tippe: " + tipp);
                
                if( tipp < szam ) {
                    pw.println("nagyobb");  //a gondolt szam ennel nagyobb
                }
                else if( tipp > szam ) {  //a gondolt szam ennel kisebb
                    pw.println("kisebb");
                }
                else {
                    pw.println("talalt");
                    talalt = true;
                }
            }
        }
    }
}
