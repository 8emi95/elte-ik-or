import java.util.Scanner;

public class Ember {

    private final String csaladNev;
    private final String utoNev;
    
    public Ember(String csaladNev, String utoNev) {
        this.csaladNev = csaladNev;
        this.utoNev    = utoNev;
    }
    
    public Ember(String line) {
        Scanner sc = new Scanner(line);
        csaladNev = sc.next();
        utoNev    = sc.next();
    }
    
    public String getCsaladNev() {
        return csaladNev;
    }
    
    public String getUtoNev() {
        return utoNev;
    }
    
    @Override
    public String toString() {
        return csaladNev + " " + utoNev;
    }
}
