//az a). es a b). feladat szandekosan ketfele megoldassal
//mindket reszt meg lehetne csinalni mindket megoldassal

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.TreeMap;

public class Main {

    public static void main(String[] args) {
        List<Ember> emberek = readFromFile("input.txt");
        
        //csaladnev szerint csoportositva
        
        Map<String, List<Ember>> groupByLastName = new TreeMap<>();
        
        for( Ember e : emberek ) {
            if( !groupByLastName.containsKey(e.getCsaladNev()) ) {
                groupByLastName.put(e.getCsaladNev(), new ArrayList<>());
            }
            groupByLastName.get(e.getCsaladNev()).add(e);
        }
        
        System.out.println("Csaladnev szerint csoportositva:\n");
        for( List<Ember> list : groupByLastName.values() ) {
            for( Ember e : list ) {
                System.out.println(e);
            }
            System.out.println();
        }
        
        //utonev szerint csoportositva
        
        emberek.sort((e1, e2) -> e1.getUtoNev().compareTo(e2.getUtoNev()));
        
        System.out.println("Csaladnev szerint csoportositva:\n");
        for( int i = 0; i < emberek.size(); ++i ) {
            Ember e = emberek.get(i);
            if( i > 0 && !emberek.get(i-1).getUtoNev().equals(emberek.get(i).getUtoNev()) ) {
                System.out.println();
            }
            System.out.println(e);
        }
    }
    
    private static List<Ember> readFromFile(String filename) {
        List<Ember> persons = new ArrayList<>();
        
        try( Scanner sc = new Scanner(new File(filename)) ) {
            while (sc.hasNextLine()) {
                persons.add(new Ember(sc.nextLine()));
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found!");
        }
        
        return persons;
    }
}
