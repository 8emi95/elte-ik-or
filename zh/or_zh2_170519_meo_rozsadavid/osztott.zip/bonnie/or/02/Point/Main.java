import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class Main {

    public static void main(String[] args) {
        List<Point> points = readFromFile("input.txt");
        
        Point origo = new Point(0, 0);
        
        //legtavolabb az origotol
        if( points.size() >= 1 ) {
            Point max = null;
            
            for (Point point : points) {
                if( max == null || point.distance(origo) > max.distance(origo) ) {
                    max = point;
                }
            }
            
            System.out.println("Legtavolabb az origotol: " + max);
        }
        
        //legkozelebb az elsohoz
        if( points.size() >= 2 ) {
            Point first = points.get(0);
            Point nearest = points.get(1);
            
            for( int i = 2; i < points.size(); ++i) {
                Point point = points.get(i);
                if( point.distance(first) < nearest.distance(first) ) {
                    nearest = point;
                }
            }
            
            System.out.println("Legkozelebb az elsohoz: " + nearest);
        }
    }
    
    //file beolvasasa
    private static List<Point> readFromFile(String fileName) {
        List<Point> result = new ArrayList<>();
        
        try (Scanner sc = new Scanner(new File(fileName))) {  //try-with-resources
            while( sc.hasNextInt() ) {
                int x = sc.nextInt();
                if( sc.hasNextInt() ) {
                    int y = sc.nextInt();
                    Point point = new Point(x, y);
                    result.add(point);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found!");
        }
        return result;
    }
}
