public class Replace {

    public static void main(String[] args) {
        for (String s : args) {
            //regularis kifejezes hasznalataval
            /*
            String changed = s.replaceAll("a+", "a");
            */
            
            //regularis kifejezes nelkul, a StringBuilder osztaly felhasznalasaval
            StringBuilder sb = new StringBuilder();
            if (s.length() > 0) {
                sb.append(s.charAt(0));
            }
            for( int i = 1; i < s.length(); ++i) {
                if( s.charAt(i) != 'a' || s.charAt(i) == 'a' && s.charAt(i - 1) != 'a' ) {
                    sb.append(s.charAt(i));
                }
            }
            
            System.out.println(sb.toString());
        }
    }
}
