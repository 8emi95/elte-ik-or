import java.util.List;
import java.util.ArrayList;

public class Pascal {

    public static void main(String[] args) {
        //feltetelezzuk, hogy parameterkent megadtak egy pozitiv egesz szamot
        int n = Integer.parseInt(args[0]);
        
        List<List<Integer>> pascal = new ArrayList<>();
        
        //elemek kiszamolasa
        for( int i = 0; i < n; ++i ) {  //i. sor
            List<Integer> list = new ArrayList<Integer>();
            
            //1. elem: 1
            list.add(1);
            
            //az elso sorban csak egy elem van
            
            if( i > 0 ) {
                for( int j = 1; j < i; ++j ) {
                    list.add(pascal.get(i-1).get(j-1) + pascal.get(i-1).get(j));
                }
                
                //utolso elem: 1
                list.add(1);
            }
            
            pascal.add(list);
        }
        
        //kiiras
        for( List<Integer> list : pascal ) {
            for( int i : list ) {
                System.out.print(i + " ");
            }
            System.out.println();
        }
    }
}
