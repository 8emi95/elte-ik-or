import java.net.*;
import java.io.*;
import java.util.*;

public class Server {

    private final int port;
    private ServerSocket server;
    private int id = 1;
    
    Server(int port) throws IOException {
        this.port = port;
        server = new ServerSocket(port);
        System.out.println("A szerver elindult.");
    }
    
    //fogadja a klienseket es minden jatekmenethez letrehoz egy uj szalat
    public void acceptClients() {
        while( true ) {
            try {
                new Game(server.accept(), server.accept(), id++).start();
            } catch( IOException e ) {
                System.err.println("Hiba a kliensek fogadasakor.");
                e.printStackTrace();
            }
        }
    }
    
    public static void main(String[] args) throws IOException {
        try {
            Server server = new Server(12345);
            server.acceptClients();
        } catch( IOException e ) {
            System.err.println("Hiba a szerver inditasanal.");
            e.printStackTrace();
        }
    }
}

//szal egy jatekmenet kezelesehez
class Game extends Thread {
    int id;  //jatek sorszama (logolashoz)
    int number;  //gondolt szam
    PrintWriter pw1, pw2;
    Scanner sc1, sc2;
    
    public Game(Socket s1, Socket s2, int id) throws IOException {
        this.id = id;
        number = new Random().nextInt(100)+1;
        System.out.println(id + ". jatekmenet: a gondolt szam: " + number);
        
        pw1 = new PrintWriter(s1.getOutputStream(), true);
        sc1 = new Scanner(s1.getInputStream());
        pw2 = new PrintWriter(s2.getOutputStream(), true);
        sc2 = new Scanner(s2.getInputStream());
    }
    
    //beolvassa a jatekos tippjet es valaszol neki; igazat ad vissza, ha a jatekos eltalalta a szamot
    public boolean handleClient(int gamer, PrintWriter pw, Scanner sc) {
        int i = sc.nextInt();
        String answer = "";
        
        if( number == i ) answer = "talalt";
        if( number < i )  answer = "kisebb";
        if( number > i )  answer = "nagyobb";
        pw.println(answer);
        
        //log
        System.out.println(id + ". jatekmenet: " + gamer + ". jatekostol olvastam: " + i + ", valszoltam: " + answer);
        
        return (number == i);
    }
    
    @Override
    public void run() {
        int gamer = 1;  //melyik jatekos jon (logolashoz)
        try {
            while( true ) {
                //felvaltva olvasunk a jatekosoktol; ha valamelyik eltalalta, akkor vege a jateknak
                gamer = 1; if( handleClient(gamer, pw1, sc1) ) break;
                gamer = 2; if( handleClient(gamer, pw2, sc2) ) break;
            }
            System.out.println(id + ". jatekmenet: " + gamer + ". jatekos kitalalta a szamot; jatek vege.");
        } catch( NoSuchElementException e ) {  //ha valamelyik klienssel megszakadt a kapcsolat (handleClient-beli sc.nextInt() dobhatja)
            System.out.println(id + ". jatekmenet: " + gamer + ". jatekossal megszakadt a kapcsolat; jatek vege.");
        } finally {
            pw1.close();
            pw2.close();
        }
    }
}
