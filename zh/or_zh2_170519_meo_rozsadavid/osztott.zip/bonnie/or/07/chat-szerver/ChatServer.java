import java.net.*;
import java.io.*;
import java.util.*;

public class ChatServer {

    private final int port;
    private ServerSocket server;
    
    //a csatlakozott kliensek halmaza (nev, hozzá tartozo pw)
    private Map<String, PrintWriter> clients = new HashMap<String, PrintWriter>();
    
    public int getPort() {
        return port;
    }
    
    ChatServer(int port) throws IOException {
        this.port = port;
        server = new ServerSocket(port);
        System.out.println("A chat szerver elindult.");
    }
    
    //fogadja a klienseket es mindegyihez letrehoz egy uj szalat
    public void handleClients() {
        while( true ) {
            try {
                new ClientHandler(server.accept()).start();
            } catch( IOException e ) {
                System.err.println("Hiba a kliensek fogadasakor.");
                e.printStackTrace();
            }
        }
    }
    
    //ellenorzi, hogy megfelelo-e a nev; es ha igen, akkor felveszi a kliensek koze
    private synchronized boolean addClient(String name, PrintWriter pw) {
        if( name.trim().equals("") || name.equals("Szerver") || clients.containsKey(name) )
            return false;
        
        send("Szerver", name + " csatlakozott.");
        clients.put(name, pw);
        return true;
    }
    
    //kivesz egy klienst
    private synchronized void removeClient(String name) {
        clients.remove(name);
    }
    
    //a kuldot kiveve mindenkinek elkuldi az uzenetet
    private synchronized void send(String name, String message) {
        String messageToSend = name + ": " + message;
        System.out.println(messageToSend);
        for( String n : clients.keySet() ) {
            if( !n.equals(name) ) {
                clients.get(n).println(messageToSend);
            }
        }
    }
    
    //szal egy kliens kezelesehez
    class ClientHandler extends Thread {
        
        PrintWriter pw;
        BufferedReader br; //itt is lehetne Scanner-rel fogadni az adatokat, de a valtozatossag kedveert legyen most BufferedReader
        String name;
        
        ClientHandler(Socket s) throws IOException {
            pw = new PrintWriter(s.getOutputStream(), true);
            br = new BufferedReader(new InputStreamReader(s.getInputStream()));
        }
        
        @Override
        public void run() {
            //nev "bekerese"
            try {
                boolean ready = false;
                while( !ready ) {
                    name = br.readLine();
                    if( name == null ) {  //ha a masik fel lezarta a csatornat (meg mielott barmit kuldott volna)
                        System.err.println("Inicializalasi problema egy kliensnel.");
                        return;
                    }
                    ready = addClient(name, pw);
                    pw.println(ready ? "ok" : "nok");
                }
            } catch( IOException e ) {  //ha a masik fellel megszakadt a kapcsolat (lezarta a csatornat vagy befejezodott)
                System.err.println("Inicializalasi problema egy kliensnel.");
                return;
            }
            
            //uzenetek fogadasa es tovabbkuldese
            boolean clientError = false;
            String message = "";
            try {
                while( !message.equals("!exit") ) {
                    message = br.readLine();
                    if( message == null ) break;
                    if( !message.equals("!exit") ) send(name, message);
                }
            } catch( IOException e ) {  //ha a masik fellel megszakadt a kapcsolat
                System.err.println("Kommunikacios problema egy kliensnel. (Nev: " + name + ")");
                clientError = true;
            } finally {
                removeClient(name);
                pw.close();
                if( clientError )
                    send("Szerver", name + " nevu felhasznaloval megszakadt a kapcsolat.");
                else
                    send("Szerver", name + " kilepett.");
            }
        }
    }
    
    public static void main(String[] args) {
        try {
            ChatServer server = new ChatServer(12345);
            server.handleClients();
        } catch( IOException e ) {
            System.err.println("Hiba a chat server inditasanal.");
            e.printStackTrace();
        }
    }

}
