import java.net.InetAddress;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;

public class RMIServer
{
    public static void main(String args[]) throws Exception {
        final int port = 12345;
        //final String host = (InetAddress.getLocalHost()).toString();
        //System.out.println("RMI server is on address: " + host + ", port: " + port);

        Registry registry = LocateRegistry.createRegistry(port);
        
        registry.rebind("rmiAreaCalculator", new RemoteAreaCalculator());
     }
}
