import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;

public class RMIClient
{
    public static void main(String args[]) throws Exception {
        String srvAddr = "localhost";
        int srvPort = 12345;

        Registry registry = LocateRegistry.getRegistry(srvAddr, srvPort);
        
        RemoteAreaCalculatorInterface rmiAreaServer = (RemoteAreaCalculatorInterface) (registry.lookup("rmiAreaCalculator"));
        Circle circle = new Circle(new Point(1,1), 3);
        System.out.println(rmiAreaServer.areaCalculate(circle));        
    }
}
