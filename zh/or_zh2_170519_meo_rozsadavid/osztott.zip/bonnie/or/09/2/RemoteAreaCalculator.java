import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;

public class RemoteAreaCalculator extends UnicastRemoteObject implements RemoteAreaCalculatorInterface {

    public RemoteAreaCalculator() throws RemoteException { }
    
    public double areaCalculate(Circle c) throws RemoteException {
        return (c.getR() * c.getR() * Math.PI);
    }    
}
