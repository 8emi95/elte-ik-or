import java.rmi.Remote;
import java.rmi.RemoteException;

public interface RemoteAreaCalculatorInterface extends Remote
{
    double areaCalculate(Circle c) throws RemoteException;
}
