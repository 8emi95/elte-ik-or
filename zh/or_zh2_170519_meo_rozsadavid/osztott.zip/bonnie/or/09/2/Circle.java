import java.io.Serializable;

public class Circle implements Serializable {

    private Point cp;
    private int r;

    public Circle(Point cp, int r) {
        this.cp = cp;
        this.r = r;
    }

    public int getR() {
        return r;
    }

    public String toString() {
        return cp + " r: " + r;
    }

}