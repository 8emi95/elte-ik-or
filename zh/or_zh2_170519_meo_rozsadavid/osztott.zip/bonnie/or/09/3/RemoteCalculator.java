import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;

public class RemoteCalculator extends UnicastRemoteObject implements RemoteCalculatorInterface {

    int number = 0;

    public RemoteCalculator() throws RemoteException { }
    
    public void nullaz() throws RemoteException {
        number = 0;
    }
    
    public int hozzaad(int i) throws RemoteException {
        number += i;
        return number;
    }
    
    public int kivon(int i) throws RemoteException {
        number -= i;
        return number;
    }
    
    public int szoroz(int i) throws RemoteException {
        number *= i;
        return number;
    }
}
