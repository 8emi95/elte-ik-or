import java.rmi.Remote;
import java.rmi.RemoteException;

public interface RemoteCalculatorInterface extends Remote
{
    void nullaz() throws RemoteException;
    int hozzaad(int i) throws RemoteException;
    int kivon(int i) throws RemoteException;
    int szoroz(int i) throws RemoteException;
}
