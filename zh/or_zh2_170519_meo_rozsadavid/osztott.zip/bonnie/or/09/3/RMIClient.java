import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;

public class RMIClient
{
    public static void main(String args[]) throws Exception {
        String srvAddr = "localhost";
        int srvPort = 12345;

        Registry registry = LocateRegistry.getRegistry(srvAddr, srvPort);
                
        RemoteCalculatorInterface rmiCalculator = (RemoteCalculatorInterface) (registry.lookup("rmiCalculator"));
        System.out.println(rmiCalculator.hozzaad(3));
        System.out.println(rmiCalculator.kivon(1));
        System.out.println(rmiCalculator.szoroz(5));
        rmiCalculator.nullaz();
        System.out.println(rmiCalculator.hozzaad(1));
        
    }
}
