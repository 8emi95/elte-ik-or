import java.rmi.Remote;
import java.rmi.RemoteException;

public interface RemoteReverseTxtInterface extends Remote
{
    String reverseTxt(String s) throws RemoteException;
}
