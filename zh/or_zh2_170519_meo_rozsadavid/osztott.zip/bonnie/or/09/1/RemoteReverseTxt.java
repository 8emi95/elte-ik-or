import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;

public class RemoteReverseTxt extends UnicastRemoteObject implements RemoteReverseTxtInterface {

    public RemoteReverseTxt() throws RemoteException { }  //kotelezo a kivetel miatt
    
    public String reverseTxt(String s) throws RemoteException {
        return (new StringBuilder(s)).reverse().toString();
    }    
}
