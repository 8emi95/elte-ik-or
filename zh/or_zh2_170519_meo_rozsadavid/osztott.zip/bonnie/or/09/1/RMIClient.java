import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;

public class RMIClient
{
    public static void main(String args[]) throws Exception {
        String srvAddr = "localhost";
        int srvPort = 12345;

        Registry registry = LocateRegistry.getRegistry(srvAddr, srvPort);
        
        RemoteReverseTxtInterface rmiServer = (RemoteReverseTxtInterface) (registry.lookup("rmiServer"));
        
        String message = "moni";
        String reply = rmiServer.reverseTxt(message);
        System.out.println(reply);        
    }
}
