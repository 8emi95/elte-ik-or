public class Fib {

    //2. Ird ki a Fibonacci-sorozat elso n elemet (az n parancssori param�ter)
    public static void main(String[] args) {        
        int n = 0;
        try {
            n = Integer.parseInt(args[0]);
            if( n <= 0 ) {
                System.out.println("A program egy pozitiv szamot var.");
                System.exit(1);
            }
        } catch( IndexOutOfBoundsException | NumberFormatException e ) {
            System.out.println("A program egy pozitiv szamot var.");
            System.exit(1);
        }
        
        System.out.println("Fibbonacci(" + n + ")=");
        System.out.println(fib2a(n));
        System.out.println(fib2b(n));
        System.out.println(fib2c(n));
    }
    
    //2/a. Fibonacci (tombben taroljuk az eddigi elemeket)
    static int fib2a(int n) {
        if( n < 3 ) return 1;
        
        int[] fib = new int[n];
        
        fib[0] = 1;
        fib[1] = 1;
        
        for( int i = 2; i < n; ++i ) {
            fib[i] = fib[i-1] + fib[i-2];
        }
        
        return fib[n-1];
    }
    
    //2/b. Fibonacci (mindig csak az elozo ket elemet taroljuk)
    static int fib2b(int n) {
        if( n < 3 ) return 1;
        
        int elozoElotti = 1;
        int elozo = 1;
        
        for( int i = 3; i <= n; ++i ) {
            int uj = elozoElotti + elozo;
            elozoElotti = elozo;
            elozo = uj;
        }
        
        return elozo;
    }
    
    //2/c. Fibonacci (rekurzioval)
    static int fib2c(int n) {
        if( n < 3 ) return 1;
        return fib2c(n-2) + fib2c(n-1);
    }
}
