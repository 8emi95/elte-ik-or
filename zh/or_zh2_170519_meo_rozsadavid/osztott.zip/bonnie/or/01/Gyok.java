public class Gyok {

    //3. Vonj negyzetgyokot egy parancssori parameterkent kapott szambol Newton-iteracioval
    public static void main(String[] args) {
        double d = 0.0;
        try {
            d = Double.parseDouble(args[0]);
            if( d < 0 ) {
                System.out.println("A program egy nemnegativ szamot var.");
                System.exit(1);
            }
        } catch( IndexOutOfBoundsException | NumberFormatException e ) {
            System.out.println("A program egy nemnegativ szamot var.");
            System.exit(1);
        }
        
        System.out.println("Gyok(" + d + ") = " + newton(d));
    }
    
    static double newton(double x) {
        double hibahatar = 0.000001;
        double also = 0;
        double felso = x;
        double gyok = x / 2;
        
        while( Math.abs(gyok*gyok - x) > hibahatar ) {
            if( gyok * gyok > x ) {
                felso = gyok;
            } else {
                also = gyok;
            }
            gyok = (felso + also) / 2;
        }
        
        return gyok;
    }
}
