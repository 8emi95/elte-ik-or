import java.util.Arrays;
import java.util.Comparator;
import java.util.Map;
import java.util.TreeMap;

/*
// 1/h, 1. megoldas (Comparator osztallyal)
class SzamCmp implements Comparator<String> {
    public int compare(String s1, String s2) {
        int i1 = Integer.parseInt(s1);
        int i2 = Integer.parseInt(s2);
        return i1 - i2;
    }
}
*/

public class Args {
    
    public static void main(String[] args) {
        feladat1a(args);
        feladat1b(args);
        feladat1c(args);
        feladat1d(args);
        feladat1e(args);
        feladat1f(args);
        feladat1g(args);
        feladat1h(args);
        feladat1i(args);
    }    

    //1/a. Ird ki a parancssori parametereket sorban
    static void feladat1a(String[] args) {
        System.out.println("\nParancssori parameterek sorban:");
        
        /*
        for (int i = 0; i < args.length; ++i) {
            System.out.println(args[i]);
        }
        */
        
        for( String arg : args ) {
            System.out.println(arg);
        }
    }
    
    //1/b. Ird ki a parancssori parametereket sorszamozva
    static void feladat1b(String[] args) {
        System.out.println("\nParancssori parameterek sorszamozva:");
        
        /*
        for (int i = 0; i < args.length; ++i) {
            System.out.println((i+1) + ". " + args[i]);
        }
        */
        
        int sorszam = 1;
        for( String arg : args ) {
            System.out.println(sorszam + ". " + arg);
            ++sorszam;
        }
    }
    
    //1/c. Ird ki a parancssori parametereket forditott sorrendben
    static void feladat1c(String[] args) {
        System.out.println("\nParancssori parameterek forditott sorrendben:");
        for (int i = args.length-1; i >= 0; --i)
            System.out.println(args[i]);
    }
    
    //1/d. Ird ki a parancssori parameterek hosszait
    static void feladat1d(String[] args) {
        System.out.println("\nParancssori parameterek hosszai:");
        
        /*
        for (int i = 0; i < args.length; ++i) {
            System.out.println(args[i].length());
        }
        */
        
        for( String arg : args ) {
            System.out.println(arg.length());
        }
    }
    
    //1/e. Ird ki a parancssori parameterek az osszeget (hagyjuk ki azokat az elemeket, amelyek nem szamok)
    static void feladat1e(String[] args) {
        int osszeg = 0;
        for( String arg : args ) {
            try {
                osszeg += Integer.parseInt(arg);
            } catch( NumberFormatException e ) {}
        }
        
        System.out.println("\nParancssori parameterek az osszege: " + osszeg);
    }
    
    static boolean parosE(String arg) {
        try {
            return Integer.parseInt(arg) % 2 == 0;
        } catch( NumberFormatException e ) {
            return false;
        }
    }
    
    //1/f. Ird ki a parancssori parameterek kozul a parosakat
    static void feladat1f(String[] args) {
        System.out.println("\nParos parameterek:");
        
        for( String arg : args ) {
            if( parosE(arg) ) {
                System.out.println(arg);
            }
        }
    }
    
    //1/g. Ird ki a parancssori parametereket sorrendben (tegyuk fel, hogy mind szoveg)
    static void feladat1g(String[] args) {
        System.out.println("\nParameterek sorrendben (lexikografikus rendezes):");
        
        Arrays.sort(args);
        for( String arg : args ) System.out.println(arg);
    }
    
    //1/h. Ird ki a parancssori parametereket sorrendben (tegyuk fel, hogy mind szam)
    static void feladat1h(String[] args) {
        System.out.println("\nParameterek sorrendben (szam erteke szerinti rendezes):");
        
        try {
            /*
            // 1/h, 1. megoldas (Comparator osztallyal)
            Arrays.sort(args, new SzamCmp());
            */
            
            /*
            // 1/h, 2. megoldas (lambda fuggvennyel)
            Arrays.sort(args, (String s1, String s2) -> {
                    int i1 = Integer.parseInt(s1);
                    int i2 = Integer.parseInt(s2);
                    return i1 - i2;
                });
            */
            
            // 1/h, 3. megoldas (lambda fuggvennyel)
            Arrays.sort(args, (s1,s2) -> Integer.parseInt(s1) - Integer.parseInt(s2));
            
            for( String arg : args ) System.out.println(arg);
        } catch( NumberFormatException e) {
            System.out.println("Valamelyik parameter nem szam.");
        }
    }
    
    //1/i. Ird ki a parancssori parameterek kozul azokat, amelyikbol tobb is talalhato
    static void feladat1i(String[] args) {
        System.out.println("\nAzon parameterek, amelyikbol tobb is van:");
        
        //parameterek feldolgozasa
        Map<String, Integer> parameterek = new TreeMap<String, Integer>();
        for( String s : args ) {
            if (parameterek.containsKey(s)) {
                int db = parameterek.get(s);
                parameterek.put(s, db + 1);
            } else {
                parameterek.put(s, 1);
            }
        }
        
        //kiiras
        for( Map.Entry<String, Integer> param : parameterek.entrySet() ) {
            if( param.getValue() > 1 )
                System.out.println(param.getKey());
        }
    }
}
