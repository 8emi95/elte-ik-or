import java.util.*;

public class Lengyel {

    public static void main(String[] args) {
        if( args.length == 0 ) System.exit(1);
        
        Stack<Integer> verem = new Stack<Integer>();
        
        for( String s : args ) {
            try {
                verem.push(Integer.parseInt(s));
            } catch( NumberFormatException e ) {
                try {
                    switch(s) {
                        case "+" : verem.push(verem.pop() + verem.pop()); break;
                        case "-" : verem.push(verem.pop() - verem.pop()); break;
                        case "*" : verem.push(verem.pop() * verem.pop()); break;
                        case "/" : verem.push(verem.pop() / verem.pop()); break;
                        default: throw new IllegalArgumentException("Nem vart elem: " + s);
                    }
                } catch( EmptyStackException e2 ) {
                    throw new IllegalArgumentException("Nincs eleg operandus a muvelethez: " + s);
                }
            }
        }
        
        if( verem.size() > 1 )
            throw new IllegalArgumentException("Az operandusok feldolgozasahoz nincs eleg muvelet");
        
        System.out.println("A vegeredmeny: " + verem.pop());
    }
}
