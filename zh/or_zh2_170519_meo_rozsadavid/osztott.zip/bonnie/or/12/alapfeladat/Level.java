import java.io.*;

public class Level implements Serializable {
    public String cimzett;
    public String cim;
    public int irsz;
    public boolean elsobbsegi;
    
    public Level(String cimzett, String cim, int irsz, boolean elsobbsegi) {
        this.cimzett    = cimzett;
        this.cim        = cim;
        this.irsz       = irsz;
        this.elsobbsegi = elsobbsegi;
    }
    
    public Level(String cimzett, String cim, int irsz) {
        this(cimzett, cim, irsz, false);
    }
    
    @Override
    public String toString() {
        return "[ " + cimzett + ", " + cim + ", " + irsz + ", " + elsobbsegi + " ]";
    }
}
