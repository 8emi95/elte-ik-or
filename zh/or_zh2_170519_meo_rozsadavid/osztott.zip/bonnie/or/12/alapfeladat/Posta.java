import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
import java.util.*;

public class Posta extends UnicastRemoteObject implements PostaInterface {
    private int ar;
    private int felar;
    
    private List<Level> sima       = new LinkedList<>();
    private List<Level> elsobbsegi = new LinkedList<>();
    
    public Posta(int ar, int felar) throws RemoteException {
        this.ar    = ar;
        this.felar = felar;
    }
    
    public synchronized int felad(Level l) throws RemoteException {
        if( l.elsobbsegi ) {
            elsobbsegi.add(l);
            return ar + felar;
        }
        else {
            sima.add(l);
            return ar;
        }
    }
    
    private boolean joLevel(Level l, byte irSzamKezdet) {
        return ((""+l.irsz).startsWith(""+irSzamKezdet));
    }
    
    private void kivesz(List<Level> honnan, List<Level> hova, byte irSzamKezdet, int taskameret) {
        int db = 0;
        int i = 0;
        while( db < taskameret && i < honnan.size() ) {
            Level l = honnan.get(i);
            if( joLevel(l, irSzamKezdet) ) {
                hova.add(l);
                honnan.remove(i);
                db++;
            }
            else
                i++;
        }
    }
    
    public synchronized List<Level> elszallit(byte irSzamKezdet, int taskameret) throws RemoteException {
        List<Level> result = new ArrayList<>();
        
        kivesz(elsobbsegi, result, irSzamKezdet, taskameret);
        kivesz(sima,       result, irSzamKezdet, taskameret-result.size());
        
        return result;
    }
    
    public static void main(String[] args) throws Exception {
        if( args.length != 2 ) {
            System.err.println("Hasznalat: Posta ar felar");
            System.exit(1);
        }
        
        int ar = 0;
        int felar = 0;
        
        try {
            ar    = Integer.parseInt(args[0]);
            felar = Integer.parseInt(args[1]);
        }
        catch( Exception e ) {
            System.err.println("Hasznalat: Posta ar felar");
            System.exit(1);
        }
        
        Registry registry = LocateRegistry.createRegistry(9000);
        
        Posta posta = new Posta(ar, felar);
        registry.rebind("posta", posta);
    }
}
