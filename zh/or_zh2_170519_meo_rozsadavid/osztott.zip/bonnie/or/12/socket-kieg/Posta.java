import java.rmi.*;
import java.rmi.server.*;
import java.rmi.registry.*;
import java.util.*;
import java.net.*;
import java.io.*;

public class Posta extends UnicastRemoteObject implements PostaInterface {
    public static final int port = 12345;

    public int ar;
    public int felar;
    
    private List<Level> sima       = new LinkedList<>();
    private List<Level> elsobbsegi = new LinkedList<>();
    
    int osszBevetel = 0;
    
    public Posta(int ar, int felar) throws RemoteException {
        this.ar    = ar;
        this.felar = felar;
    }
    
    public synchronized int felad(Level l) throws RemoteException {
        int dij;
        if( l.elsobbsegi ) {
            elsobbsegi.add(l);
            dij = ar + felar;
        }
        else {
            sima.add(l);
            dij = ar;
        }
        
        osszBevetel += dij;
        
        return dij;
    }
    
    private boolean joLevel(Level l, byte irSzamKezdet) {
        return ((""+l.irsz).startsWith(""+irSzamKezdet));
    }
    
    private void kivesz(List<Level> honnan, List<Level> hova, byte irSzamKezdet, int taskameret) {
        int db = 0;
        int i = 0;
        while( db < taskameret && i < honnan.size() ) {
            Level l = honnan.get(i);
            if( joLevel(l, irSzamKezdet) ) {
                hova.add(l);
                honnan.remove(i);
                db++;
            }
            else
                i++;
        }
    }
    
    public synchronized List<Level> elszallit(byte irSzamKezdet, int taskameret) throws RemoteException {
        List<Level> result = new ArrayList<>();
        
        kivesz(elsobbsegi, result, irSzamKezdet, taskameret);
        kivesz(sima,       result, irSzamKezdet, taskameret-result.size());
        
        return result;
    }
    
    public synchronized int arModosit(double modosito) {
        ar = (int)Math.round(((double)ar)*modosito);
        System.out.println("Az uj ar: " + ar);
        return ar;
    }
    
    public synchronized int felarModosit(double modosito) {
        felar = (int)Math.round(((double)felar)*modosito);
        System.out.println("Az uj felar: " + felar);
        return felar;
    }
    
    public synchronized int bevetelLekerdez() {
        System.out.println("Az eddigi bevetel: " + osszBevetel);
        return osszBevetel;
    }
    
    public static void main(String[] args) throws Exception {
        if( args.length != 2 ) {
            System.err.println("Hasznalat: Posta ar felar");
            System.exit(1);
        }
        
        int ar = 0;
        int felar = 0;
        
        try {
            ar    = Integer.parseInt(args[0]);
            felar = Integer.parseInt(args[1]);
        }
        catch( Exception e ) {
            System.err.println("Hasznalat: Posta ar felar");
            System.exit(1);
        }
        
        Registry registry = LocateRegistry.createRegistry(9000);
        
        Posta posta = new Posta(ar, felar);
        registry.rebind("posta", posta);
        
        (new ArKezelo(posta)).start();
    }
    
    //-----------------------------------------------------------------------
    
    static class ArKezelo extends Thread {
        Posta posta;
        
        public ArKezelo(Posta posta) {
            this.posta = posta;
        }
        
        @Override
        public void run() {
            try {
                ServerSocket ss = new ServerSocket(port);
                
                while( true ) {
                    try {
                        Socket s = ss.accept();
                        Scanner input = new Scanner(s.getInputStream());
                        PrintWriter output = new PrintWriter(s.getOutputStream(), true); 
                        
                        while( input.hasNextLine() ) {
                            String keres = input.nextLine();
                            System.out.println("Keres erkezett: " + keres);
                            
                            double modosito = 0;
                            
                            if( keres.startsWith("ar ") ) {
                                try {
                                    modosito = Double.parseDouble(keres.substring(3));
                                }
                                catch( NumberFormatException e ) {
                                    System.out.println("Hibas keres.");
                                    continue;
                                }
                                output.println(posta.arModosit(modosito));
                            }
                            
                            else if( keres.startsWith("felar ") ) {
                                try {
                                    modosito = Double.parseDouble(keres.substring(6));
                                }
                                catch( NumberFormatException e ) {
                                    System.out.println("Hibas keres.");
                                    continue;
                                }
                                output.println(posta.felarModosit(modosito));
                            }
                            
                            else if( keres.equals("bevetel") ) {
                                output.println(posta.bevetelLekerdez());
                            }
                            
                            else {
                                System.out.println("Hibas keres.");
                            }
                        }
                        
                        output.close();
                        s.close();
                    }
                    catch( Exception e ) {
                        System.out.println("Szerver hiba; varunk egy uj kliensre");
                        continue;
                    }
                }
            }
            catch( Exception e ) {
                System.out.println("Socket hiba");
            }
        }
    }
}
