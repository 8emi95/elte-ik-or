import java.rmi.registry.*;

public class Felado {
    int id;
    PostaInterface posta;
    
    public Felado(int id) throws Exception {
        this.id = id;
        
        Registry registry = LocateRegistry.getRegistry("localhost", 9000);
        posta =  (PostaInterface) registry.lookup("posta");
    }
    
    private Level general(int i, int id) {
        return new Level("cimzett" + id, "cim" + id, i * 1000 + id, (id+i)%2 == 0);
    }
    
    private void felad(int hanyMasodpercenkent, int hanyszor) throws Exception {
        for( int i = 0; i < hanyszor; ++i ) {
            Level l = general(i+1, id);
            int ar = posta.felad(l);
            
            System.out.println("feladtam: " + l + ", ar: " + ar);
            
            Thread.sleep(hanyMasodpercenkent * 1000);
        }
    }
    
    public static void main(String[] args) throws Exception {
        if( args.length != 1 ) {
            System.err.println("Hasznalat: Felado id");
            System.exit(1);
        }
        
        int id = 0;
        try {
            id = Integer.parseInt(args[0]);
        }
        catch( Exception e ) {
            System.err.println("Hasznalat: Felado id");
            System.exit(1);
        }
        
        if( id < 0 || id > 100 ) {
            System.err.println("Az id legyen 1 es 100 kozott.");
            System.exit(1);
        }
        
        Felado felado = new Felado(id);
        felado.felad(2, 9);
    }
}
