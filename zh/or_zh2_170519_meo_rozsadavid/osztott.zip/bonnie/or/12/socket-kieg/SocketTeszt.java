import java.net.*;
import java.util.*;
import java.io.*;

class SocketTeszt {
    public static void main(String[] args) throws java.io.IOException {
    
        final String gep = "localhost";
        final int port = 12345;
        Socket s = new Socket(gep, port);

        Scanner input = new Scanner(s.getInputStream());
        PrintWriter output = new PrintWriter(s.getOutputStream(), true);
        
        //hibas keresek
        output.println("ar");
        output.println("ar ");
        output.println("ar  ");
        output.println("ar alma");
        output.println("felar");
        output.println("felar ");
        output.println("felar  ");
        output.println("felar alma");
        output.println("bevetel korte");
        output.println("semmi");
        
        //jo keresek
        
        output.println("ar 2");
        System.out.println("Az uj ar: " + input.nextLine());
        
        output.println("felar 0.5");
        System.out.println("Az uj felar: " + input.nextLine());

        output.println("bevetel");
        System.out.println("Az eddigi bevetel: " + input.nextLine());        

        output.close();
        s.close();
    }
} 