import java.rmi.*;
import java.util.*;

public interface PostaInterface extends Remote {
    int felad(Level l) throws RemoteException;
    List<Level> elszallit(byte irSzamKezdet, int taskameret) throws RemoteException;
}