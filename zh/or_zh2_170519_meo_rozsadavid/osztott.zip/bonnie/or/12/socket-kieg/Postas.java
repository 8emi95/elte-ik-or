import java.rmi.registry.*;
import java.util.*;

public class Postas {
    byte irSzamKezdet;
    int taskameret;
    PostaInterface posta;
    Random rand = new Random();
    
    public Postas(byte irSzamKezdet, int taskameret) throws Exception {
        this.irSzamKezdet = irSzamKezdet;
        this.taskameret   = taskameret;
        
        Registry registry = LocateRegistry.getRegistry("localhost", 9000);
        posta =  (PostaInterface) registry.lookup("posta");
    }
    
    private void elszallit(int minMp, int maxMp) throws Exception {
        while( true ) {
            List<Level> levelek = posta.elszallit(irSzamKezdet, taskameret);
            
            System.out.println("Elszallitok: ");
            for(Level l : levelek)
                System.out.println("   " + l);

            Thread.sleep((rand.nextInt(maxMp-minMp+1)+minMp) * 1000);
        }
    }
    
    public static void main(String[] args) throws Exception {
        if( args.length != 2 ) {
            System.err.println("Hasznalat: Postas iranyitoszamkezdet taskameret");
            System.exit(1);
        }
        
        byte irSzamKezdet = 0;
        int taskameret = 0;
        try {
            irSzamKezdet = (byte) Integer.parseInt(args[0]);
            taskameret = Integer.parseInt(args[1]);
        }
        catch( Exception e ) {
            System.err.println("Hasznalat: Postas iranyitoszamkezdet taskameret");
            System.exit(1);
        }
        
        if( irSzamKezdet <= 0 || taskameret <= 0 ) {
            System.err.println("Mindket parameter pozitiv legyen.");
            System.exit(1);
        }
        
        Postas postas = new Postas(irSzamKezdet, taskameret);
        postas.elszallit(1, 5);
    }
}
