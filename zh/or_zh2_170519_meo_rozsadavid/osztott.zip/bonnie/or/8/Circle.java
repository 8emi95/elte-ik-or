public class Circle {

    private Point cp;
    private int r;
    private Double area = null;

    public Circle(Point cp, int r) {
        this.cp = cp;
        this.r = r;
    }

    public double getArea() {
        if (area == null) {
            area = new Double(r * r * Math.PI);
        }
        return area;
    }

    public String toString() {
        return cp + " r: " + r + " area: " + area;
    }

    public void move(int dx, int dy) {
        cp.move(dx, dy);
    }
}