import java.net.*;
import java.io.*;
import java.util.*;

public class Ember {

    PrintWriter pw;
    Scanner sc;
    
    private String nev;
    private int penz;
    Scanner tippolvaso;

    public final int VARAKOZAS = 1000;
    public final int DIJ = 2;
    public static final int DB = 5;
   
    public Ember(Socket s, String nev, int penz, String fajlnev) throws IOException {
        pw = new PrintWriter(s.getOutputStream(), true);
        sc = new Scanner(s.getInputStream());
        
        this.nev = nev;
        this.penz = penz;
        tippolvaso = new Scanner(new File(fajlnev));
    }

    private void log(String szoveg) {
        System.out.println(nev + "> " + szoveg);
    }

    public void jatszik() throws IOException {
        while (penz >= DIJ) {
            Set<Integer> tipp = new HashSet<Integer>();
            for (int i=0; i<DB; i++) {
                tipp.add(tippolvaso.nextInt());   
            }
            try {
                pw.println("JATSZIK");
                for (int i : tipp) {
                    pw.println(i);   
                }
                int nyeremeny = sc.nextInt();
                penz += nyeremeny;
                log("tipp: " + tipp + "; kifizetes: " + nyeremeny + "; penzem: " + penz);
                try {
                    Thread.sleep(VARAKOZAS);
                } catch (InterruptedException e) {}
            } catch (/*UnsupportedOperationException*/ NoSuchElementException e) {
                log("A lottozas befejezodott, mert a lottozo csodbe ment.");
                break;
            }
        }
        if (penz < DIJ) log("A lottozas befejezodott, mert elfogyott a penzem.");
    } 
   
    public static void main(String[] args) throws IOException {
        Socket s = new Socket("localhost", 8899);
        
        Ember ember = new Ember(s, args[0], Integer.parseInt(args[1]), args[2]);
        ember.jatszik();
    }
}
