import java.net.*;
import java.io.*;
import java.util.*;

public class Lottozo {

    public static final int DB = 5;
    public static final int MAX = 90;
    public static final int DIJ = -2;
    public static final int NYEREMENY = 5;
    public static final String CSOD = "Csodbe ment a lottozo.";

    private int kassza;

    private Set<Integer> nyeroszamok = new HashSet<Integer>();
 
    private Random rand = new Random(123456);

    public Lottozo(int kassza) {
        this.kassza = kassza;
    }
    
    public void mukodik(ServerSocket ss) throws IOException {
        while (true) {
            Socket s = ss.accept();
            new Handler(s).start();
        }
    }
    
    public synchronized void sorsol() {
        if (kassza <= 0) throw new UnsupportedOperationException(CSOD);

        nyeroszamok.clear();
        while (nyeroszamok.size() < DB) {
            nyeroszamok.add(rand.nextInt(MAX) + 1);
        } 
        log("sorsolas: " + nyeroszamok);
    }

    public synchronized int jatszik(Set<Integer> szamok) {
        if (kassza <= 0) throw new UnsupportedOperationException(CSOD);

        int nyeremeny = DIJ;
        int talalat = 0;
        for (int szam : szamok) {
             if (nyeroszamok.contains(szam)) talalat++;
        }
        if (talalat >= 2) nyeremeny += talalat * NYEREMENY;
        kassza -= nyeremeny;
        
        log("tipp: " + szamok + "; kifizetes: " + nyeremeny + "; uj kassza: " + kassza);

        if (kassza <= 0) throw new UnsupportedOperationException(CSOD);

        return nyeremeny;
    }
    
    private void log(String szoveg) {
        System.out.println("L> " + szoveg);
    }

    public static void main(String[] args) throws Exception {
        ServerSocket ss = new ServerSocket(8899);

        Lottozo l = new Lottozo(Integer.parseInt(args[0]));
        l.mukodik(ss);
    }
    
    //fogadja a feladatokat
    class Handler extends Thread {
        
        Socket s;
        
        Handler(Socket s) {
            this.s = s;
        }
        
        @Override
        public void run() {
            try (
                PrintWriter pw = new PrintWriter(s.getOutputStream(), true);
                Scanner sc = new Scanner(s.getInputStream());
            ) {
                while( true ) {
                    String parancs = sc.next();
                    switch( parancs ) {
                    
                        case "SORSOL":
                            sorsol();
                            
                            //jelzes, hogy kesz a feladat
                            pw.println(0);
                            break;
                            
                        case "JATSZIK":
                            //parameterek beolvasasa
                            Set<Integer> tipp = new HashSet<Integer>();
                            for( int i = 0; i < DB; i++ )
                                tipp.add(sc.nextInt());
                            
                            //feladat elvegzese
                            int nyeremeny = jatszik(tipp);
                            
                            //visszateresi ertek visszakuldese
                            pw.println(nyeremeny);
                            break;
                    }
                }
            } catch( IOException | NoSuchElementException /*| InputMismatchException*/ e ) {
                log("hiba az egyik keresben");
            } catch ( UnsupportedOperationException e ) {}
        }
    }
}
