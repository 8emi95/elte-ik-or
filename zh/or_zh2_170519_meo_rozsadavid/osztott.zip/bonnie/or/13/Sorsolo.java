import java.net.*;
import java.io.*;
import java.util.*;

public class Sorsolo {
    
    PrintWriter pw;
    Scanner sc;
    
    public final int VARAKOZAS = 1000;

    public Sorsolo(Socket s) throws IOException {
        pw = new PrintWriter(s.getOutputStream(), true);
        sc = new Scanner(s.getInputStream());
    }

    public void sorsolgat() throws IOException {
        while (true) {
            try { 
                pw.println("SORSOL");
                sc.nextInt(); //megvarjuk a veget
            } catch (/*UnsupportedOperationException*/ NoSuchElementException e) {break;}
            try {
                Thread.sleep(VARAKOZAS);
            } catch (InterruptedException e) {}
        }    
    }

    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("localhost", 8899);

        Sorsolo s = new Sorsolo(socket);
        s.sorsolgat();
    }
}
