import java.io.Serializable;

public class BinFa implements Serializable {
	// tfh implement�lva van...
}
